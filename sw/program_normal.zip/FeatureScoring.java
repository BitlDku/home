/**
   Feature Scoreing using various FS algorithm   
*/

import java.io.*;
import java.util.StringTokenizer;

import net.sf.javaml.core.Dataset;
import net.sf.javaml.featureselection.scoring.*;
import net.sf.javaml.tools.data.FileHandler;


class FeatureScoring 
{
	// Parameters ///////////////////////////////////////////////////////////////////////////////
	
	double [][] trainData ;
	int NO_OF_FEATURE ;

	/////////////////////////////////////////////////////////////////////////////////////////////
	// Constractor /////////////////////////////////////////////////////////////////////////////

	public FeatureScoring (double [][] getTrainData)
	{
		trainData = getTrainData ;
		NO_OF_FEATURE = trainData[0].length -1;

		saveTemporalFile();

	}

	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	public void saveTemporalFile()
	{
		try {
			FileWriter   fw_1 = new FileWriter("./tmp/tmpTrainData.txt");  
			BufferedWriter bw_1 = new BufferedWriter(fw_1);     
			PrintWriter outFile_1 = new PrintWriter(bw_1);  


			for(int i=0; i< trainData.length; i++)
			{
				for(int j=0; j< trainData[0].length; j++)
				{
					outFile_1.print(trainData[i][j] + ",");
				}
				outFile_1.println("");
			}

			outFile_1.close();  

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	public void saveResult(double [] result)
	{

		try {
			FileWriter   fw_1 = new FileWriter("./tmp/tmpFScore.txt");  //��������
			BufferedWriter bw_1 = new BufferedWriter(fw_1);     //��¹�������
			PrintWriter outFile_1 = new PrintWriter(bw_1);  //��� ��ü ����


			for(int i=0; i< result.length; i++)
			{
				outFile_1.println(result[i]);
			}

			outFile_1.close();  

		} catch (IOException e) {
			System.err.println(e); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}

	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public void FSGainRatio()
	{
		double [] Fscore = new double [NO_OF_FEATURE] ;

		try {
			Dataset data = FileHandler.loadDataset(new File("./tmp/tmpTrainData.txt"), 0, ",");		

			/* Create a feature scoring algorithm */
			GainRatio ga = new GainRatio();
			
			/* Apply the algorithm to the data set */
			ga.build(data);
			
			/* Print out the score of each attribute */
			for (int i = 0; i < ga.noAttributes(); i++)
				Fscore[i] = ga.score(i);			

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
		saveResult(Fscore) ;

	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public void FSRelief()
	{
		double [] Fscore = new double [NO_OF_FEATURE] ;

		try {
			Dataset data = FileHandler.loadDataset(new File("./tmp/tmpTrainData.txt"), 0, ",");		

			/* Create a feature scoring algorithm */
			RELIEF rf = new RELIEF();
			
			/* Apply the algorithm to the data set */
			rf.build(data);
			
			/* Print out the score of each attribute */
			for (int i = 0; i < rf.noAttributes(); i++)
				Fscore[i] = rf.score(i);			

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
		saveResult(Fscore) ;

	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	public void FSKnn()
	{
		double [] Fscore = new double [NO_OF_FEATURE] ;

		try {

			for (int i=1; i<trainData[0].length; i++)
			{
				double [][] singleFeature = new double [trainData.length][2] ;
				for (int j=0; j<trainData.length; j++)
				{
					singleFeature[j][0] = trainData[j][0];
					singleFeature[j][1] = trainData[j][i];
				}

				// Save single feature data
				String saveTR = "./tmp/tmpSingleFeature.txt";
				FileWriter   fw_1 = new FileWriter(saveTR);  
				BufferedWriter bw_1 = new BufferedWriter(fw_1);     
				PrintWriter outFile_1 = new PrintWriter(bw_1);  

				for(int k=0; k< singleFeature.length; k++)
				{
					for(int j=0; j< singleFeature[0].length; j++)
					{
						outFile_1.print(singleFeature[k][j] + ",");
					}
					outFile_1.println("");
				}
				outFile_1.close();  

				// do classification test on single feature data				
				Classifiers cr = new Classifiers(saveTR, saveTR);
				Fscore[i-1] = cr.KNN(5); // accuracy is evaluation score  
			}

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
		saveResult(Fscore) ;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	public void FSSvm()
	{
		double [] Fscore = new double [NO_OF_FEATURE] ;

		try {

			for (int i=1; i<trainData[0].length; i++)
			{
				double [][] singleFeature = new double [trainData.length][2] ;
				for (int j=0; j<trainData.length; j++)
				{
					singleFeature[j][0] = trainData[j][0];
					singleFeature[j][1] = trainData[j][i];
				}

				// Save single feature data
				String saveTR = "./tmp/tmpSingleFeature.txt";
				FileWriter   fw_1 = new FileWriter(saveTR);  
				BufferedWriter bw_1 = new BufferedWriter(fw_1);     
				PrintWriter outFile_1 = new PrintWriter(bw_1);  

				for(int k=0; k< singleFeature.length; k++)
				{
					for(int j=0; j< singleFeature[0].length; j++)
					{
						outFile_1.print(singleFeature[k][j] + ",");
					}
					outFile_1.println("");
				}
				outFile_1.close();  

				// do classification test on single feature data				
				Classifiers cr = new Classifiers(saveTR, saveTR);
				Fscore[i-1] = cr.SVM();     
			}

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
		saveResult(Fscore) ;
	}
}