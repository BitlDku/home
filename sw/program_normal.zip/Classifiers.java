/**
   Test classifier using java-ml library   
*/

import java.io.*;
import java.util.StringTokenizer;

import net.sf.javaml.classification.Classifier;
import net.sf.javaml.classification.KNearestNeighbors;
import net.sf.javaml.classification.ZeroR;
import net.sf.javaml.core.*;
import net.sf.javaml.tools.data.FileHandler;

import net.sf.javaml.tools.weka.WekaClassifier;
import weka.classifiers.functions.SMO;                   // SMO SVM
import weka.classifiers.functions.Logistic;              // Logistic Regression  
import weka.classifiers.bayes.NaiveBayes ;               // Naive Bayes
import weka.classifiers.lazy.KStar ;                     // KStar   


public class Classifiers 
{
	// Parameters ///////////////////////////////////////////////////////////////////////////////
	
	String trainData, testData ;

	/////////////////////////////////////////////////////////////////////////////////////////////
	// Constractor /////////////////////////////////////////////////////////////////////////////

	public Classifiers (String getTrainData, String getTestData)
	{
		trainData = getTrainData;
		testData = getTestData ;
	}

	
	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double KNN(int no_of_k)
	{
		double accuracy = 0;
        int correct = 0, wrong = 0;

		try {
			// Load a data set 
			Dataset data = FileHandler.loadDataset(new File(trainData), 0, ","); // 0: column of class label
			
			 //Contruct a KNN classifier that uses k neighbors to make a decision.
			Classifier knn = new KNearestNeighbors(no_of_k);
			knn.buildClassifier(data);

			// Load a data set for evaluation, this can be a different one, but we
			// will use the same one.
			Dataset dataForClassification = FileHandler.loadDataset(new File(testData), 0, ",");

			/* Counters for correct and wrong predictions. */
			/* Classify all instances and check with the correct class values */
			for (Instance inst : dataForClassification) {
				Object predictedClassValue = knn.classify(inst);
				Object realClassValue = inst.classValue();
				if (predictedClassValue.equals(realClassValue))
					correct++;
				else
					wrong++;
			}
		} catch (IOException IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}

		accuracy = (double)correct/(double)(correct + wrong) ;
		return accuracy ;
	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double ZeroR() 
	{
		double accuracy = 0;
        int correct = 0, wrong = 0;

		try {
			// Load a data set 
			Dataset data = FileHandler.loadDataset(new File(trainData), 0, ","); // 0: column of class label
			
			 //Contruct a SOM classifier that uses k neighbors to make a decision.
			Classifier zeroR = new ZeroR();
			zeroR.buildClassifier(data);

			// Load a data set for evaluation, this can be a different one, but we
			// will use the same one.
			Dataset dataForClassification = FileHandler.loadDataset(new File(testData), 0, ",");

			/* Counters for correct and wrong predictions. */
			/* Classify all instances and check with the correct class values */
			for (Instance inst : dataForClassification) {
				Object predictedClassValue = zeroR.classify(inst);
				Object realClassValue = inst.classValue();
				if (predictedClassValue.equals(realClassValue))
					correct++;
				else
					wrong++;
			}
		} catch (IOException IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}

		accuracy = (double)correct/(double)(correct + wrong) ;
		return accuracy ;
	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double SVM()
	{
		double accuracy = 0;
		int correct = 0, wrong = 0;
		try {
			// Load a data set 
			Dataset data = FileHandler.loadDataset(new File(trainData), 0, ","); // 0: column of class label
			
			/* Create Weka classifier */
			SMO smo = new SMO();
			/* Wrap Weka classifier in bridge */
			Classifier javamlsmo = new WekaClassifier(smo);
			javamlsmo.buildClassifier(data);

			// Load a data set for evaluation, this can be a different one, but we
			// will use the same one.
			Dataset dataForClassification = FileHandler.loadDataset(new File(testData), 0, ",");

			/* Counters for correct and wrong predictions. */
			/* Classify all instances and check with the correct class values */
			for (Instance inst : dataForClassification) {
				Object predictedClassValue = javamlsmo.classify(inst);
				Object realClassValue = inst.classValue();
				if (predictedClassValue.equals(realClassValue))
					correct++;
				else
					wrong++;
			}
		} catch (IOException IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}


		accuracy = (double)correct/(double)(correct + wrong) ;
		return accuracy ;
	}
	
	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double NB() // Naive Bayes
	{
		double accuracy = 0;
		int correct = 0, wrong = 0;
		try {
			// Load a data set 
			Dataset data = FileHandler.loadDataset(new File(trainData), 0, ","); // 0: column of class label
			
			/* Create Weka classifier */
			NaiveBayes nb = new NaiveBayes();
			/* Wrap Weka classifier in bridge */
			Classifier javamlnb = new WekaClassifier(nb);
			javamlnb.buildClassifier(data);

			// Load a data set for evaluation, this can be a different one, but we
			// will use the same one.
			Dataset dataForClassification = FileHandler.loadDataset(new File(testData), 0, ",");

			/* Counters for correct and wrong predictions. */
			/* Classify all instances and check with the correct class values */
			for (Instance inst : dataForClassification) {
				Object predictedClassValue = javamlnb.classify(inst);
				Object realClassValue = inst.classValue();
				if (predictedClassValue.equals(realClassValue))
					correct++;
				else
					wrong++;
			}
		} catch (IOException IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}


		accuracy = (double)correct/(double)(correct + wrong) ;
		return accuracy ;
	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double LOGISTIC() // logistic regression
	{
		double accuracy = 0;
		int correct = 0, wrong = 0;
		try {
			// Load a data set 
			Dataset data = FileHandler.loadDataset(new File(trainData), 0, ","); // 0: column of class label
			
			/* Create Weka classifier */
			Logistic lc = new Logistic();
			/* Wrap Weka classifier in bridge */
			Classifier javamllc = new WekaClassifier(lc);
			javamllc.buildClassifier(data);

			// Load a data set for evaluation, this can be a different one, but we
			// will use the same one.
			Dataset dataForClassification = FileHandler.loadDataset(new File(testData), 0, ",");

			/* Counters for correct and wrong predictions. */
			/* Classify all instances and check with the correct class values */
			for (Instance inst : dataForClassification) {
				Object predictedClassValue = javamllc.classify(inst);
				Object realClassValue = inst.classValue();
				if (predictedClassValue.equals(realClassValue))
					correct++;
				else
					wrong++;
			}
		} catch (IOException IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}


		accuracy = (double)correct/(double)(correct + wrong) ;
		return accuracy ;
	}


	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double KStar() // KStar
	{
		double accuracy = 0;
		int correct = 0, wrong = 0;
		try {
			// Load a data set 
			Dataset data = FileHandler.loadDataset(new File(trainData), 0, ","); // 0: column of class label
			
			/* Create Weka classifier */
			KStar lc = new KStar();
			/* Wrap Weka classifier in bridge */
			Classifier javamllc = new WekaClassifier(lc);
			javamllc.buildClassifier(data);

			// Load a data set for evaluation, this can be a different one, but we
			// will use the same one.
			Dataset dataForClassification = FileHandler.loadDataset(new File(testData), 0, ",");

			/* Counters for correct and wrong predictions. */
			/* Classify all instances and check with the correct class values */
			for (Instance inst : dataForClassification) {
				Object predictedClassValue = javamllc.classify(inst);
				Object realClassValue = inst.classValue();
				if (predictedClassValue.equals(realClassValue))
					correct++;
				else
					wrong++;
			}
		} catch (IOException IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}


		accuracy = (double)correct/(double)(correct + wrong) ;
		return accuracy ;
	}


}