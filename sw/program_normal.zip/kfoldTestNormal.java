/**
  [ BIT LAB. OFFICIAL ALGORITHM ]   	

  K Fold Test Algorithm for normal classification with feature selction
  Ver. 2012-05-04
  
*/


import java.io.*;
import java.util.StringTokenizer;
import java.util.ArrayList;

import net.sf.javaml.core.*; 
import net.sf.javaml.classification.*; 

class kfoldTestNormal 
{
	// Parameters ///////////////////////////////////////////////////////////////////////////////
	String dataSetName ;                    // class info. should be in first column
	int NO_OF_FOLD ;						// no of fold
	int NO_OF_REPEAT ;						// no of repeat for Kfold test
	int ID_CLASSIFIER ;						// ID of classifier
	int ID_FS ;								// ID of Feature selection algorithms
	int NO_OF_SELECTED_FEATURE ;			// no of selected feature
	int NO_OF_K;							// no of k for KNN
	/////////////////////////////////////////////////////////////////////////////////////////////
	
	int NO_OF_DATA ;
	int NO_OF_FEATURE ;
	int NO_OF_CLASS ;
	
	double [][] totalData ;
	double [][] trainData  ;
	double [][] testData  ;

	int [] cntClass ;                                   // number of instance for each class

	double final_accuarcy =0;							// final accuracy

	
	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	public void parseParm()
	{
		String s1;
		try {
			BufferedReader in = new BufferedReader(new FileReader("parameter.txt"));
			int cnt = 0, tmpClass =-1, tmpFeature =-1;  
			while ((s1 = in.readLine()) != null)
			{
				StringTokenizer token = new StringTokenizer(s1, ":");
				
				String parm = token.nextToken().trim();
				StringTokenizer content = new StringTokenizer(token.nextToken().trim(), "/");
				int parmValue = Integer.parseInt(content.nextToken().trim());
				
				if (parm.equals("NO_OF_FOLD"))
					NO_OF_FOLD = parmValue ;
				else if (parm.equals("NO_OF_REPEAT"))
					NO_OF_REPEAT = parmValue ;
				else if (parm.equals("CLASSIFIER"))
					ID_CLASSIFIER = parmValue ;
				else if (parm.equals("FEATURE_SELECTION"))
					ID_FS = parmValue ;
				else if (parm.equals("SELECTED_FEATURE"))
					NO_OF_SELECTED_FEATURE = parmValue ;
				else if (parm.equals("KNN"))
					NO_OF_K = parmValue ;

			}
			in.close(); 
		} catch (IOException IOe) {
			System.err.println(IOe); // print error message
			System.exit(1);
		}

	}

	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	public String getNameFs(int no)
	{
		String name ="";
		if (no == 1 ) name = "Relief";
		else if (no == 2) name = "GainRatio";
		else if (no == 3) name = "FS-SVM";
		else if (no == 4) name = "FS-KNN";
		
		return name ;
	}
	//--------------------------------------------------
	public String getNameClassifier(int no)
	{
		String name ="";
		if (no == 1 ) name = "KNN";
		else if (no == 2 ) name = "KStar";
		else if (no == 3 ) name = "SVM";
		else if (no == 4 ) name = "Naive Bayes";
		else if (no == 5 ) name = "Logistic Regression";
		
		return name ;
	}


	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	public void findBasicInfo()
	{
		String s1;
		try {
			BufferedReader in = new BufferedReader(new FileReader(dataSetName));
			int cnt = 0, tmpClass =-1, tmpFeature =-1;  
			while ((s1 = in.readLine()) != null)
			{
				StringTokenizer token = new StringTokenizer(s1, ",");
				
				tmpFeature = token.countTokens(); 
				int getClass = (int)Double.parseDouble(token.nextToken().trim());         // class info
				if (getClass > tmpClass)
					tmpClass = getClass;

				cnt++;
			}
			
			in.close(); 

			// basic info -------------------------------------------
			NO_OF_DATA = cnt;
			NO_OF_CLASS = tmpClass + 1;
			NO_OF_FEATURE = tmpFeature -1;	

			System.out.println("** Dataset     : " + dataSetName);
			System.out.println("No of instance : " + NO_OF_DATA);
			System.out.println("No of class    : " + NO_OF_CLASS);
			System.out.println("No of feature  : " + NO_OF_FEATURE);
			System.out.println("" );

			System.out.println("No of repeat   : " + NO_OF_REPEAT);

			System.out.println("No of fold     : " + NO_OF_FOLD);
			System.out.println("Classifier     : " + getNameClassifier(ID_CLASSIFIER));
			System.out.println("Feature Selection       : " + getNameFs(ID_FS));
			System.out.println("No of selected features : " + NO_OF_SELECTED_FEATURE);
			System.out.println("" );

			totalData = new double[NO_OF_DATA][NO_OF_FEATURE+1];
			cntClass  = new int[NO_OF_CLASS];

		} catch (IOException IOe) {
			System.err.println(IOe); // print error message
			System.exit(1);
		}
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	public void loadData()
	{
		String s1 ;
		try {
			BufferedReader in = new BufferedReader(new FileReader(dataSetName));
			
			for (int i=0; i<NO_OF_DATA; i++)
			{
				s1 = in.readLine();
				StringTokenizer token = new StringTokenizer(s1, ",");
				for (int j=0; j <= NO_OF_FEATURE; j++)
				{
					totalData[i][j] = Double.parseDouble(token.nextToken().trim());
				}
				cntClass[(int)totalData[i][0]]++;        // count number of instances for each class
			}

			in.close(); 

		} catch (IOException IOe) {
			System.err.println(IOe);
			System.exit(1);
		}
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	public void saveTrainTestData(int no_of_feature, String saveTR, String saveTS, double [] rank)
	{

		try {
			// read feature rank info  --------------------------------------------------
			String s1 ;
			int [] fRank = new int[NO_OF_FEATURE];
			
			for (int j=0; j < NO_OF_FEATURE; j++)
				fRank[j] = (int)rank[j];

			// Save Train data ---------------------------------------------------------
			FileWriter   fw_1 = new FileWriter(saveTR);  
			BufferedWriter bw_1 = new BufferedWriter(fw_1);     
			PrintWriter outFile_1 = new PrintWriter(bw_1);  


			for(int i=0; i< trainData.length; i++)
			{
				for(int j=0; j< trainData[0].length; j++)  // feature
				{
					if (j==0 || fRank[j-1]< no_of_feature)           // error   
						outFile_1.print(trainData[i][j] + ",");
				}
				outFile_1.println("");
			}
			outFile_1.close();  

			// Save Test data ----------------------------------------------------------
			FileWriter   fw_2 = new FileWriter(saveTS);  
			BufferedWriter bw_2 = new BufferedWriter(fw_2);     
			PrintWriter outFile_2 = new PrintWriter(bw_2);  

			for(int i=0; i< testData.length; i++)
			{
				for(int j=0; j< testData[0].length; j++)
				{
					if (j==0 || fRank[j-1]<no_of_feature)
						outFile_2.print(testData[i][j] + ",");
				}
				outFile_2.println("");
			}
			outFile_2.close();  

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	public void runKfold(String dsName)
	{

		for (int x=0; x<NO_OF_REPEAT; x++)
		{
			double accuracy = 0;
			ArrayList <Integer> idx = new ArrayList <Integer>(); 
			for (int i=0; i<NO_OF_DATA; i++)
				idx.add(i);

			int [][] foldInfo = new int [NO_OF_FOLD][NO_OF_DATA/NO_OF_FOLD+1] ;
			for (int i=0; i<NO_OF_FOLD; i++)  // initialize 
				for (int j=0; j<foldInfo[0].length; j++)
					foldInfo[i][j] = -1;

			for (int i=0; i<foldInfo[0].length; i++)  // fold
			{
				for (int j=0; j<NO_OF_FOLD; j++)
				{
					if (idx.size() == 0) break;

					int pick = (int)(Math.random()*idx.size());
					foldInfo[j][i] = idx.remove(pick);
				}
				if (idx.size() == 0) break;
			}

			for (int i=0; i<NO_OF_FOLD; i++)
			{
				System.out.print(".");
				// Step 1. find no_of_train, no_of_test 
				int noTrain =0, noTest = 0;
				int [] idxArr = new int [NO_OF_DATA];
				for (int k=0; k< foldInfo[0].length; k++)
					if (foldInfo[i][k] > -1)
					{
						noTest++;
						idxArr[foldInfo[i][k]] = 1;	
					}

				noTrain = NO_OF_DATA - noTest ;

				// Step.2 make train/test dataset
				trainData = new double [noTrain][NO_OF_FEATURE+1] ;
				testData = new double [noTest][NO_OF_FEATURE+1] ;

				int cntTR =0, cntTS =0;

				for (int j=0; j<NO_OF_DATA; j++)
					if (idxArr[j] == 1)
					{
						testData[cntTS] = totalData[j] ;
						cntTS ++ ;
					} else {
						trainData[cntTR] = totalData[j] ;
						cntTR++;
					}

				// step 3. feture evaluate for trainData
				FeatureRanking fs = new FeatureRanking(trainData);     // for producing evaluation values
				if (ID_FS == 1)		 fs.FSRelief();    // feature evaluation (ranking)
				else if (ID_FS == 2) fs.FSGainRatio() ;
				else if (ID_FS == 3) fs.FSSvm();
				else if (ID_FS == 4) fs.FSKnn(); 
				
				String saveTR = "./tmp/tmpTrainDataset.csv";
				String saveTS = "./tmp/tmpTestDataset.csv";
				
				double [] rank = fs.getRank();
				saveTrainTestData(NO_OF_SELECTED_FEATURE, saveTR, saveTS, rank);  // temporally save two feature selected datasets
				// step 4. test classifier 
				Classifiers cr = new Classifiers(saveTR, saveTS);
				if (ID_CLASSIFIER == 1) accuracy = cr.KNN(NO_OF_K);
				else if	(ID_CLASSIFIER == 2) accuracy = cr.KStar();
				else if	(ID_CLASSIFIER == 3) accuracy = cr.SVM();
				else if	(ID_CLASSIFIER == 4) accuracy = cr.NB();
				else if	(ID_CLASSIFIER == 5) accuracy = cr.LOGISTIC();

				final_accuarcy += accuracy ;
			}

		} // end for(x)
		final_accuarcy /= (double)(NO_OF_REPEAT*NO_OF_FOLD);
		System.out.println("");
		System.out.println("Accuracy : "  + final_accuarcy);
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	public double getAccuracy()
	{
		return final_accuarcy ;
	}

	////////////////////////////////////////////////////////////////////////////////////////////
/*
	public void saveData(double dataArr[][], String fName)
	{
		try {
			// save training data
			FileWriter   fw_1 = new FileWriter(fName);  
			BufferedWriter bw_1 = new BufferedWriter(fw_1);     
			PrintWriter outFile_1 = new PrintWriter(bw_1);  

			
			for (int i=0; i<dataArr.length; i++)
			{
				outFile_1.print((int)dataArr[i][0]+1);  

				for (int k=0; k<NO_OF_FEATURE; k++)
				{
					outFile_1.print(" " + (k+1) + ":" + dataArr[i][k+1]);
				}
				outFile_1.println("");
			}
			outFile_1.close(); 
			} catch (IOException IOe) {
			System.err.println(IOe); 
			System.exit(1);
		}

	}
*/
	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	public static void main(String[] args) throws IOException 
	{

		kfoldTestNormal obj = new kfoldTestNormal();

		String fileName = args[0].trim();  // get file name 
			obj.dataSetName = fileName;
			obj.parseParm();               // parsing parameter.txt file
			obj.findBasicInfo();
			obj.loadData();
			obj.runKfold(fileName); // (1)make kfold data (2)feature evaluation (3) classification test

	}
}
