/**
   Feature ranking using various FS algorithm   
*/

import java.io.*;
import java.util.StringTokenizer;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

import net.sf.javaml.core.Dataset;
import net.sf.javaml.featureselection.ranking.RankingFromScoring ;
import net.sf.javaml.featureselection.scoring.* ;
import net.sf.javaml.tools.data.FileHandler;

class FeatureRanking 
{
	// Parameters ///////////////////////////////////////////////////////////////////////////////
	
	double [][] trainData ;
	int NO_OF_FEATURE ;
	double [] Frank ; 

	/////////////////////////////////////////////////////////////////////////////////////////////
	// Constractor /////////////////////////////////////////////////////////////////////////////

	public FeatureRanking (double [][] getTrainData)
	{
		trainData = getTrainData ;
		NO_OF_FEATURE = trainData[0].length -1;

		saveTemporalFile();
		Frank = new double [NO_OF_FEATURE] ;

	}

	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	public void saveTemporalFile()
	{
		try {
			FileWriter   fw_1 = new FileWriter("./tmp/tmpTrainData.txt");  
			BufferedWriter bw_1 = new BufferedWriter(fw_1);     
			PrintWriter outFile_1 = new PrintWriter(bw_1);  


			for(int i=0; i< trainData.length; i++)
			{
				for(int j=0; j< trainData[0].length; j++)
				{
					outFile_1.print(trainData[i][j] + ",");
				}
				outFile_1.println("");
			}

			outFile_1.close();  

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double [] makeRank(double [] Score)
	{
		double [] Rank = new double [Score.length];
		double [] tmpScore = new double [Score.length];
		for (int i=0; i<Score.length; i++)  // copy
			tmpScore[i] = Score[i];

		Arrays.sort(tmpScore);    
		ArrayList<Double> list = new ArrayList<Double>();  
		for (int i=Score.length-1; i>=0; i--)  // ascending order to descending order
			list.add(tmpScore[i]);
		
		int [] found = new int [Rank.length];
		for (int i=0; i<Score.length; i++)
		{
			int fidx = list.indexOf(Score[i]);
			int pos = fidx + found[fidx];
			Rank[i] = pos;
			found[fidx]++;
		}

		return Rank;
	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public void FSGainRatio()
	{

		try {
			Dataset data = FileHandler.loadDataset(new File("./tmp/tmpTrainData.txt"), 0, ",");		

			/* Create a feature ranking algorithm */

			RankingFromScoring ga = new RankingFromScoring(new GainRatio());  
			
			/* Apply the algorithm to the data set */
			ga.build(data);
			
			/* Print out the rank of each attribute */
			for (int i = 0; i < ga.noAttributes(); i++)
				Frank[i] = ga.rank(i);			

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}

	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public void FSRelief()
	{
		try {
			Dataset data = FileHandler.loadDataset(new File("./tmp/tmpTrainData.txt"), 0, ",");		

			/* Create a feature scoring algorithm */
			RankingFromScoring rf = new RankingFromScoring(new RELIEF());  
			
			/* Apply the algorithm to the data set */
			rf.build(data);
			
			/* Print out the rank of each attribute */
			for (int i = 0; i < rf.noAttributes(); i++)
				Frank[i] = rf.rank(i);			

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}

	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public void FSKnn()
	{
		double [] Score = new double [NO_OF_FEATURE] ;
		double [] Frank = new double [NO_OF_FEATURE] ;
		FeatureScoring fs = new FeatureScoring(trainData);
		fs.FSKnn(); // create feature score file

		try {
			// read score file ---------------------------------------------------
			String s1;
			BufferedReader in = new BufferedReader(new FileReader("./tmp/tmpFScore.txt"));
			
			for (int i=0; i<NO_OF_FEATURE; i++)
			{
				s1 = in.readLine();
				Score[i] = Double.parseDouble(s1.trim());
			}
			in.close(); 

			// make rank ---------------------------------------------------------
			Frank = makeRank(Score);

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}

	}

	
	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	public void FSSvm()
	{
		double [] Score = new double [NO_OF_FEATURE] ;
		double [] Frank = new double [NO_OF_FEATURE] ;
		FeatureScoring fs = new FeatureScoring(trainData);
		fs.FSSvm(); // create feature score file

		try {
			// read score file ---------------------------------------------------
			String s1;
			BufferedReader in = new BufferedReader(new FileReader("./tmp/tmpFScore.txt"));
			
			for (int i=0; i<NO_OF_FEATURE; i++)
			{
				s1 = in.readLine();
				Score[i] = Double.parseDouble(s1.trim());
			}
			in.close(); 

			// make rank ---------------------------------------------------------
			Frank = makeRank(Score);

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
	}

	///////////////////////////////////////////////////////////////////////////////
	public double [] getRank()
	{
		return Frank ;
	}

}