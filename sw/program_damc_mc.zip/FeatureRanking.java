/**
   Feature ranking using various FS algorithm  (for each class) 
*/

import java.io.*;
import java.util.StringTokenizer;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

import net.sf.javaml.core.Dataset;
import net.sf.javaml.featureselection.ranking.RankingFromScoring ;
import net.sf.javaml.featureselection.scoring.* ;
import net.sf.javaml.tools.data.FileHandler;


class FeatureRanking 
{
	// Parameters ///////////////////////////////////////////////////////////////////////////////
	
	double [][] trainData ;
	int NO_OF_FEATURE ;
	int NO_OF_CLASS ;

	/////////////////////////////////////////////////////////////////////////////////////////////
	// Constractor /////////////////////////////////////////////////////////////////////////////

	public FeatureRanking (double [][] getTrainData, int no_of_class )
	{
		trainData = getTrainData ;
		NO_OF_FEATURE = trainData[0].length -1;
		NO_OF_CLASS = no_of_class;

//		saveTemporalFile();
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	public void saveTemporalFile(double [][] classDataset, int classNo)
	{
		try {
			FileWriter   fw_1 = new FileWriter("./tmp/tmpFsTrainData_"+classNo+".txt");  
			BufferedWriter bw_1 = new BufferedWriter(fw_1);     
			PrintWriter outFile_1 = new PrintWriter(bw_1);  


			for(int i=0; i< classDataset.length; i++)
			{
				for(int j=0; j< classDataset[0].length; j++)
				{
					outFile_1.print(classDataset[i][j] + ",");
				}
				outFile_1.println("");
			}

			outFile_1.close();  

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	public void saveResult(double [] result, int classNo)
	{

		try {
			FileWriter   fw_1 = new FileWriter("./tmp/tmpFRank_" + classNo +".txt");  
			BufferedWriter bw_1 = new BufferedWriter(fw_1);     
			PrintWriter outFile_1 = new PrintWriter(bw_1);  


			for(int i=0; i< result.length; i++)
			{
				outFile_1.println(result[i]);
			}

			outFile_1.close();  

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}

	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double [] makeRank(double [] Score)
	{
		double [] Rank = new double [Score.length];
		double [] tmpScore = new double [Score.length];
		for (int i=0; i<Score.length; i++)  // copy
			tmpScore[i] = Score[i];

		Arrays.sort(tmpScore);    
		ArrayList<Double> list = new ArrayList<Double>();  
		for (int i=Score.length-1; i>=0; i--)  // ascending order to descending order
			list.add(tmpScore[i]);
		
		int [] found = new int [Rank.length];
		for (int i=0; i<Score.length; i++)
		{
			int fidx = list.indexOf(Score[i]);
			int pos = fidx + found[fidx];
			Rank[i] = pos;
			found[fidx]++;
		}

		return Rank;
	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public void FSGainRatio()
	{
		double [] Frank = new double [NO_OF_FEATURE] ;

		for (int x=0; x<NO_OF_CLASS; x++)
		{
			// make class dataset
			double [][] classDataset = new double [trainData.length][trainData[0].length];
			for (int y=0; y<trainData.length; y++)
				for (int z=0; z<trainData[0].length; z++)
					if (z==0) {
						if (trainData[y][z] == x)
							classDataset[y][z] = 1;
						else
							classDataset[y][z] = 0;
					} else
						classDataset[y][z] = trainData[y][z];

			saveTemporalFile(classDataset, x);

			try {
				Dataset data = FileHandler.loadDataset(new File("./tmp/tmpFsTrainData_"+x+".txt"), 0, ",");		

				/* Create a feature ranking algorithm */

				RankingFromScoring ga = new RankingFromScoring(new GainRatio());  
				
				/* Apply the algorithm to the data set */
				ga.build(data);
				
				/* Print out the rank of each attribute */
				for (int i = 0; i < ga.noAttributes(); i++)
					Frank[i] = ga.rank(i);			

			} catch (IOException e) {
				System.err.println(e); 
				System.exit(1);
			}
			saveResult(Frank, x) ;
		} // end for(x)		


	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public void FSRelief()
	{
		double [] Frank = new double [NO_OF_FEATURE] ;

		for (int x=0; x<NO_OF_CLASS; x++)
		{
			// make class dataset
			double [][] classDataset = new double [trainData.length][trainData[0].length];
			for (int y=0; y<trainData.length; y++)
				for (int z=0; z<trainData[0].length; z++)
					if (z==0) {
						if (trainData[y][z] == x)
							classDataset[y][z] = 1;
						else
							classDataset[y][z] = 0;
					} else
						classDataset[y][z] = trainData[y][z];

			saveTemporalFile(classDataset, x);

			try {
				Dataset data = FileHandler.loadDataset(new File("./tmp/tmpFsTrainData_"+x+".txt"), 0, ",");		

				/* Create a feature scoring algorithm */
				RankingFromScoring rf = new RankingFromScoring(new RELIEF());  
				
				/* Apply the algorithm to the data set */
				rf.build(data);
				
				/* Print out the rank of each attribute */
				for (int i = 0; i < rf.noAttributes(); i++)
					Frank[i] = rf.rank(i);			

			} catch (IOException e) {
				System.err.println(e); 
				System.exit(1);
			}
			saveResult(Frank, x) ;
		} // end for(x)		

	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public void FSKnn()
	{
		double [] Score = new double [NO_OF_FEATURE] ;
		double [] Frank = new double [NO_OF_FEATURE] ;

		for (int x=0; x<NO_OF_CLASS; x++)
		{
			// make class dataset
			double [][] classDataset = new double [trainData.length][trainData[0].length];
			for (int y=0; y<trainData.length; y++)
				for (int z=0; z<trainData[0].length; z++)
					if (z==0) {
						if (trainData[y][z] == x)
							classDataset[y][z] = 1;
						else
							classDataset[y][z] = 0;
					} else
						classDataset[y][z] = trainData[y][z];

//			saveTemporalFile(classDataset, x);
			//
			FeatureScoring fs = new FeatureScoring(classDataset);
			fs.FSKnn(x); // create feature score file

			try {
				// read score file ---------------------------------------------------
				String s1;
				BufferedReader in = new BufferedReader(new FileReader("./tmp/tmpFScore_"+x+".txt"));
				
				for (int i=0; i<NO_OF_FEATURE; i++)
				{
					s1 = in.readLine();
					Score[i] = Double.parseDouble(s1.trim());
				}
				in.close(); 

				// make rank ---------------------------------------------------------
				Frank = makeRank(Score);

			} catch (IOException e) {
				System.err.println(e); 
				System.exit(1);
			}
			saveResult(Frank, x) ;
		} // end for(x)	

	}

	
	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	public void FSSvm()
	{
		double [] Score = new double [NO_OF_FEATURE] ;
		double [] Frank = new double [NO_OF_FEATURE] ;

		for (int x=0; x<NO_OF_CLASS; x++)
		{
			// make class dataset
			double [][] classDataset = new double [trainData.length][trainData[0].length];
			for (int y=0; y<trainData.length; y++)
				for (int z=0; z<trainData[0].length; z++)
					if (z==0) {
						if (trainData[y][z] == x)
							classDataset[y][z] = 1;
						else
							classDataset[y][z] = 0;
					} else
						classDataset[y][z] = trainData[y][z];

			FeatureScoring fs = new FeatureScoring(classDataset);
			fs.FSSvm(x); // create feature score file
			try {
				// read score file ---------------------------------------------------
				String s1;
				BufferedReader in = new BufferedReader(new FileReader("./tmp/tmpFScore_"+x+".txt"));
				
				for (int i=0; i<NO_OF_FEATURE; i++)
				{
					s1 = in.readLine();
					Score[i] = Double.parseDouble(s1.trim());
				}
				in.close(); 

				// make rank ---------------------------------------------------------
				Frank = makeRank(Score);

			} catch (IOException e) {
				System.err.println(e); 
				System.exit(1);
			}
			saveResult(Frank, x) ;
		} // end for(x)

	}

}