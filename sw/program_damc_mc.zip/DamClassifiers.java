/**
   Test classifier using java-ml library  
   Implement divide and merge classifiers
*/

import java.io.*;
import java.util.StringTokenizer;
import java.util.Map;

import net.sf.javaml.classification.Classifier;
import net.sf.javaml.classification.KNearestNeighbors;
import net.sf.javaml.classification.ZeroR;
import net.sf.javaml.core.*;
import net.sf.javaml.tools.data.FileHandler;
 
import net.sf.javaml.tools.weka.WekaClassifier;
import weka.classifiers.functions.SMO;                   // SMO SVM
import weka.classifiers.functions.Logistic;              // Logistic Regression  
import weka.classifiers.bayes.NaiveBayes ;               // Naive Bayes
import weka.classifiers.lazy.KStar ;                     // KStar   

import weka.core.converters.ConverterUtils.DataSource;
import weka.core.Instances;

public class DamClassifiers 
{
	// Parameters ///////////////////////////////////////////////////////////////////////////////
	
	String trainData, testData ;
	int NO_OF_FEATURE ;
	int NO_OF_CLASS ;
	int NO_OF_TEST_DATA ;
	int [] answerTable ;
		
	/////////////////////////////////////////////////////////////////////////////////////////////
	// Constractor /////////////////////////////////////////////////////////////////////////////

	public DamClassifiers (int no_of_class, int no_of_test_data, int [] answer)
	{
		NO_OF_CLASS = no_of_class;
		NO_OF_TEST_DATA = no_of_test_data;
		answerTable = answer ;                           // correct class for test dataset      
	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	private double clacAccuracy(double [][] svTable)
	{
		int correct =0;
		double accuracy ;
		
		for (int i=0; i<NO_OF_TEST_DATA; i++)
		{
			double max = svTable[i][0]; int predictedClass = 0;
			for (int c=0; c<NO_OF_CLASS; c++)
				if (svTable[i][c] > max)
				{
					max = svTable[i][c] ;
					predictedClass = c ;
				}
			if(predictedClass == answerTable[i])
				correct ++;
		}
		accuracy  = (double)correct / (double)NO_OF_TEST_DATA ;
		return accuracy ;
			
	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double KNN(int no_of_k)
	{
		double accuracy = 0;
        int correct = 0, wrong = 0;
		double [][] svTable = new double [NO_OF_TEST_DATA][NO_OF_CLASS] ; // support value table

		try {
			for (int c=0; c< NO_OF_CLASS; c++)
			{
				trainData = "./tmp/tmpTrainData_"+c+".txt";
				testData = "./tmp/tmpTestData_"+c+".txt";
					
				// Load a data set 
				Dataset data = FileHandler.loadDataset(new File(trainData), 0, ","); // 0: column of class label
				
				 //Contruct a KNN classifier that uses k neighbors to make a decision.
				Classifier knn = new KNearestNeighbors(no_of_k);
				knn.buildClassifier(data);

				// Load a data set for evaluation, this can be a different one, but we
				// will use the same one.
				Dataset dataForClassification = FileHandler.loadDataset(new File(testData), 0, ",");

				/* Counters for correct and wrong predictions. */
				/* Classify all instances and check with the correct class values */
				int cnt =0;
				for (Instance inst : dataForClassification) {
					Object predictedClassValue = knn.classify(inst);
//					Object realClassValue = inst.classValue();
					
					if (predictedClassValue.equals("1.0"))
						svTable[cnt][c] = knn.supportValue(inst);
					else
						svTable[cnt][c] = no_of_k - knn.supportValue(inst);
					cnt++;
				}

			} // end for(i)

//			for (int s=0; s<svTable.length; s++)
//			{
//				for (int t=0; t<svTable[0].length; t++)
//					System.out.print((int)svTable[s][t] + ",");
//				System.out.println("//" + answerTable[s]);
//			}

		} catch (IOException IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}

		accuracy = clacAccuracy(svTable);
		return accuracy ;
	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double ZeroR() 
	{
		double accuracy = 0;
        int correct = 0, wrong = 0;
		double [][] svTable = new double [NO_OF_TEST_DATA][NO_OF_CLASS] ; // support value table

		try {
			for (int c=0; c< NO_OF_CLASS; c++)
			{
				trainData = "./tmp/tmpTrainData_"+c+".txt";
				testData = "./tmp/tmpTestData_"+c+".txt";

				// Load a data set 
				Dataset data = FileHandler.loadDataset(new File(trainData), 0, ","); // 0: column of class label
				
				 //Contruct a SOM classifier that uses k neighbors to make a decision.
				Classifier zeroR = new ZeroR();
				zeroR.buildClassifier(data);

				// Load a data set for evaluation, this can be a different one, but we
				// will use the same one.
				Dataset dataForClassification = FileHandler.loadDataset(new File(testData), 0, ",");

				/* Counters for correct and wrong predictions. */
				/* Classify all instances and check with the correct class values */
				int cnt =0;
				for (Instance inst : dataForClassification) {
					Object predictedClassValue = zeroR.classify(inst);
//					Object realClassValue = inst.classValue();

					if (predictedClassValue.equals("1.0"))
						svTable[cnt][c] = zeroR.supportValue(inst);
					else
						svTable[cnt][c] = -1 ;
					cnt++;
				}
			} // end for(i)

		} catch (IOException IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}

		accuracy = clacAccuracy(svTable);
 
		return accuracy ;
	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double SVM()
	{
		double accuracy = 0;
		int correct = 0, wrong = 0;
		double [][] svTable = new double [NO_OF_TEST_DATA][NO_OF_CLASS] ; // support value table

		try {
			for (int c=0; c< NO_OF_CLASS; c++)
			{
				trainData = "./tmp/tmpTrainData_"+c+".arff";
				testData = "./tmp/tmpTestData_"+c+".arff";

				// Load training data set 
				 DataSource trainSource = new DataSource(trainData);
				 Instances instances = trainSource.getDataSet();

				 // Make the last attribute be the class
				 instances.setClassIndex(instances.numAttributes() - 1);

				
				/* Create Weka classifier */
				SMO smo = new SMO();
				smo.buildClassifier(instances);

				// Load test data set 
				 DataSource testSource = new DataSource(testData);
				 Instances instances2 = testSource.getDataSet();

				 // Make the last attribute be the class
				 instances2.setClassIndex(instances.numAttributes() - 1);

				/* Counters for correct and wrong predictions. */
				/* Classify all instances and check with the correct class values */
				int cnt =0;
				for (int k=0; k<instances2.numInstances(); k++ ) {
					double predictedClassValue = smo.classifyInstance(instances2.instance(k));
					//Object realClassValue = inst.classValue();
					//SVMOutput
					
					
					double [] ds = smo.distributionForInstance2(instances2.instance(k));
					//System.out.println("/"+instances2.instance(k)+"/" );
					//System.out.println("//" + ds[0] + "," + ds[1] + "//" + cnt + "//" + predictedClassValue);
					//System.out.println(instances2.numInstances());
					svTable[cnt][c] = ds[1] ;
					cnt++;

				}
			} // end for(i)

		} catch (Exception IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}


		accuracy = clacAccuracy(svTable);
		return accuracy ;
	}
	
	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double NB() // Naive Bayes
	{
		double accuracy = 0;
		int correct = 0, wrong = 0;
		double [][] svTable = new double [NO_OF_TEST_DATA][NO_OF_CLASS] ; // support value table

		try {
			for (int c=0; c< NO_OF_CLASS; c++)
			{
				trainData = "./tmp/tmpTrainData_"+c+".txt";
				testData = "./tmp/tmpTestData_"+c+".txt";

				// Load a data set 
				Dataset data = FileHandler.loadDataset(new File(trainData), 0, ","); // 0: column of class label
				
				/* Create Weka classifier */
				NaiveBayes nb = new NaiveBayes();
				/* Wrap Weka classifier in bridge */
				Classifier javamlnb = new WekaClassifier(nb);
				javamlnb.buildClassifier(data);

				// Load a data set for evaluation, this can be a different one, but we
				// will use the same one.
				Dataset dataForClassification = FileHandler.loadDataset(new File(testData), 0, ",");

				/* Counters for correct and wrong predictions. */
				/* Classify all instances and check with the correct class values */
				int cnt=0;
				for (Instance inst : dataForClassification) {
					//Object predictedClassValue = javamlnb.classify(inst);
					//Object realClassValue = inst.classValue();

					Map<Object, Double> distribution = javamlnb.classDistribution(inst);

					String getValue = distribution.get("1.0").toString();
					svTable[cnt][c] = Double.parseDouble(getValue) ;

					cnt++;
				}
			} // end for(i)
		} catch (IOException IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}

		accuracy = clacAccuracy(svTable) ;
		return accuracy ;
	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double LOGISTIC() // logistic regression
	{
		double accuracy = 0;
		int correct = 0, wrong = 0;
		double [][] svTable = new double [NO_OF_TEST_DATA][NO_OF_CLASS] ; // support value table

		try {
			for (int c=0; c< NO_OF_CLASS; c++)
			{
				trainData = "./tmp/tmpTrainData_"+c+".txt";
				testData = "./tmp/tmpTestData_"+c+".txt";

				// Load a data set 
				Dataset data = FileHandler.loadDataset(new File(trainData), 0, ","); // 0: column of class label
				
				/* Create Weka classifier */
				Logistic lc = new Logistic();
				/* Wrap Weka classifier in bridge */
				Classifier javamllc = new WekaClassifier(lc);
				javamllc.buildClassifier(data);

				// Load a data set for evaluation, this can be a different one, but we
				// will use the same one.
				Dataset dataForClassification = FileHandler.loadDataset(new File(testData), 0, ",");

				/* Counters for correct and wrong predictions. */
				/* Classify all instances and check with the correct class values */
				int cnt=0;
				for (Instance inst : dataForClassification) {
					//Object predictedClassValue = javamllc.classify(inst);
					//Object realClassValue = inst.classValue();
					Map<Object, Double> distribution = javamllc.classDistribution(inst);

					String getValue = distribution.get("1.0").toString();
					svTable[cnt][c] = Double.parseDouble(getValue) ;
					cnt++;
				}

			} // end for(i)
		} catch (IOException IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}


		accuracy = clacAccuracy(svTable) ;
		return accuracy ;
	}




	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public double KStar() // KStar
	{
		double accuracy = 0;
		int correct = 0, wrong = 0;
		double [][] svTable = new double [NO_OF_TEST_DATA][NO_OF_CLASS] ; // support value table

		try {
			for (int c=0; c< NO_OF_CLASS; c++)
			{
				trainData = "./tmp/tmpTrainData_"+c+".txt";
				testData = "./tmp/tmpTestData_"+c+".txt";

				// Load a data set 
				Dataset data = FileHandler.loadDataset(new File(trainData), 0, ","); // 0: column of class label
				
				/* Create Weka classifier */
				KStar lc = new KStar();
				/* Wrap Weka classifier in bridge */
				Classifier javamllc = new WekaClassifier(lc);
				javamllc.buildClassifier(data);

				// Load a data set for evaluation, this can be a different one, but we
				// will use the same one.
				Dataset dataForClassification = FileHandler.loadDataset(new File(testData), 0, ",");

				/* Counters for correct and wrong predictions. */
				/* Classify all instances and check with the correct class values */
				int cnt=0;
				for (Instance inst : dataForClassification) {
					//Object predictedClassValue = javamllc.classify(inst);
					//Object realClassValue = inst.classValue();
					Map<Object, Double> distribution = javamllc.classDistribution(inst);

					String getValue = distribution.get("1.0").toString();
					svTable[cnt][c] = Double.parseDouble(getValue) ;
					cnt++;
				}

			} // end for(i)
		} catch (IOException IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}


		accuracy = clacAccuracy(svTable) ;
		return accuracy ;
	}

}