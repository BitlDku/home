/**
   Feature Scoreing using various FS algorithm   
*/

import java.io.*;
import java.util.StringTokenizer;

import net.sf.javaml.core.Dataset;
import net.sf.javaml.featureselection.scoring.*;
import net.sf.javaml.tools.data.FileHandler;
import net.sf.javaml.classification.Classifier;
import net.sf.javaml.core.*;
import net.sf.javaml.classification.KNearestNeighbors;

import weka.classifiers.functions.SMO;                   // SMO SVM
import net.sf.javaml.tools.weka.WekaClassifier;

class FeatureScoring 
{
	// Parameters ///////////////////////////////////////////////////////////////////////////////
	
	double [][] trainData ;
	int NO_OF_FEATURE ;

	/////////////////////////////////////////////////////////////////////////////////////////////
	// Constractor /////////////////////////////////////////////////////////////////////////////

	public FeatureScoring (double [][] getTrainData)
	{
		trainData = getTrainData ;
		NO_OF_FEATURE = trainData[0].length -1;

		saveTemporalFile();

	}

	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	public void saveTemporalFile()
	{
		try {
			FileWriter   fw_1 = new FileWriter("./tmp/tmpTrainData.txt");  
			BufferedWriter bw_1 = new BufferedWriter(fw_1);     
			PrintWriter outFile_1 = new PrintWriter(bw_1);  


			for(int i=0; i< trainData.length; i++)
			{
				for(int j=0; j< trainData[0].length; j++)
				{
					outFile_1.print(trainData[i][j] + ",");
				}
				outFile_1.println("");
			}

			outFile_1.close();  

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	public void saveResult(double [] result, int classNo)
	{

		try {
			FileWriter   fw_1 = new FileWriter("./tmp/tmpFScore_"+classNo+".txt");  
			BufferedWriter bw_1 = new BufferedWriter(fw_1);     
			PrintWriter outFile_1 = new PrintWriter(bw_1);  


			for(int i=0; i< result.length; i++)
			{
				outFile_1.println(result[i]);
			}

			outFile_1.close();  

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}

	}
/*
	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public void FSGainRatio()
	{
		double [] Fscore = new double [NO_OF_FEATURE] ;

		try {
			Dataset data = FileHandler.loadDataset(new File("./tmp/tmpTrainData.txt"), 0, ",");		

			// Create a feature scoring algorithm 
			GainRatio ga = new GainRatio();
			
			// Apply the algorithm to the data set 
			ga.build(data);
			
			// Print out the score of each attribute 
			for (int i = 0; i < ga.noAttributes(); i++)
				Fscore[i] = ga.score(i);			

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
		saveResult(Fscore) ;

	}

	////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////
	public void FSRelief()
	{
		double [] Fscore = new double [NO_OF_FEATURE] ;

		try {
			Dataset data = FileHandler.loadDataset(new File("./tmp/tmpTrainData.txt"), 0, ",");		

			// Create a feature scoring algorithm 
			RELIEF rf = new RELIEF();
			
			// Apply the algorithm to the data set 
			rf.build(data);
			
			// Print out the score of each attribute 
			for (int i = 0; i < rf.noAttributes(); i++)
				Fscore[i] = rf.score(i);			

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
		saveResult(Fscore) ;

	}
*/	
	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	public void FSKnn(int classNo)
	{
		double [] Fscore = new double [NO_OF_FEATURE] ;

		try {

			for (int i=1; i<trainData[0].length; i++)
			{
				double [][] singleFeature = new double [trainData.length][2] ;
				for (int j=0; j<trainData.length; j++)
				{
					singleFeature[j][0] = trainData[j][0];
					singleFeature[j][1] = trainData[j][i];
				}

				// Save single feature data
				String saveTR = "./tmp/tmpSingleFeature_"+i+".txt";
				FileWriter   fw_1 = new FileWriter(saveTR);  
				BufferedWriter bw_1 = new BufferedWriter(fw_1);     
				PrintWriter outFile_1 = new PrintWriter(bw_1);  

				for(int k=0; k< singleFeature.length; k++)
				{
					for(int j=0; j< singleFeature[0].length; j++)
					{
						outFile_1.print(singleFeature[k][j] + ",");
					}
					outFile_1.println("");
				}
				outFile_1.close();  

				// do classification test on single feature data
				//int no_of_class, int no_of_test_data, int [] answer
				int [] answer = new int [trainData.length];
				for (int q=0; q<trainData.length; q++)
					answer[q] = (int)trainData[q][0];

				Fscore[i-1] = KNN(5, saveTR); // accuracy is evaluation score  
			}

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
		saveResult(Fscore, classNo) ;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////
	public void FSSvm(int classNo)
	{
		double [] Fscore = new double [NO_OF_FEATURE] ;

		try {

			for (int i=1; i<trainData[0].length; i++)
			{
				double [][] singleFeature = new double [trainData.length][2] ;
				for (int j=0; j<trainData.length; j++)
				{
					singleFeature[j][0] = trainData[j][0];   // class NO
					singleFeature[j][1] = trainData[j][i];
				}

				// Save single feature data
				String saveTR = "./tmp/tmpSingleFeature_"+i+".txt";
				FileWriter   fw_1 = new FileWriter(saveTR);  
				BufferedWriter bw_1 = new BufferedWriter(fw_1);     
				PrintWriter outFile_1 = new PrintWriter(bw_1);  

				for(int k=0; k< singleFeature.length; k++)
				{
					for(int j=0; j< singleFeature[0].length; j++)
					{
						outFile_1.print(singleFeature[k][j] + ",");
					}
					outFile_1.println("");
				}
				outFile_1.close();  

				// do classification test on single feature data	
				int [] answer = new int [trainData.length];
				for (int q=0; q<trainData.length; q++)
					answer[q] = (int)trainData[q][0];

				Fscore[i-1] = SVM(saveTR);   // accuracy is evaluation score  
			}

		} catch (IOException e) {
			System.err.println(e); 
			System.exit(1);
		}
		saveResult(Fscore, classNo) ;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////
	public double SVM(String dataFileName)
	{
		double accuracy = 0;
		int correct = 0, wrong = 0;
		try {
			// Load a data set 
			Dataset data = FileHandler.loadDataset(new File(dataFileName), 0, ","); // 0: column of class label
			
			/* Create Weka classifier */
			SMO smo = new SMO();
			/* Wrap Weka classifier in bridge */
			Classifier javamlsmo = new WekaClassifier(smo);
			javamlsmo.buildClassifier(data);

			// Load a data set for evaluation, this can be a different one, but we
			// will use the same one.
			Dataset dataForClassification = FileHandler.loadDataset(new File(dataFileName), 0, ",");

			/* Counters for correct and wrong predictions. */
			/* Classify all instances and check with the correct class values */
			for (Instance inst : dataForClassification) {
				Object predictedClassValue = javamlsmo.classify(inst);
				Object realClassValue = inst.classValue();
				if (predictedClassValue.equals(realClassValue))
					correct++;
				else
					wrong++;
			}
		} catch (IOException IOe) {
			System.err.println(IOe); 
			System.exit(1);
		}

		accuracy = (double)correct/(double)(correct + wrong) ;
		return accuracy ;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////
	public double KNN(int no_of_k, String dataFileName)
	{
		double accuracy = 0;
        int correct = 0, wrong = 0;

		try {
			// Load a data set 
			Dataset data = FileHandler.loadDataset(new File(dataFileName), 0, ","); // 0: column of class label
			
			 //Contruct a KNN classifier that uses k neighbors to make a decision.
			Classifier knn = new KNearestNeighbors(no_of_k);
			knn.buildClassifier(data);

			// Load a data set for evaluation, this can be a different one, but we
			// will use the same one.
			Dataset dataForClassification = FileHandler.loadDataset(new File(dataFileName), 0, ",");

			/* Counters for correct and wrong predictions. */
			/* Classify all instances and check with the correct class values */
			for (Instance inst : dataForClassification) {
				Object predictedClassValue = knn.classify(inst);
				Object realClassValue = inst.classValue();
				if (predictedClassValue.equals(realClassValue))
					correct++;
				else
					wrong++;
			}
		} catch (IOException IOe) {
			System.err.println(IOe); 
			System.exit(1);
		}

		accuracy = (double)correct/(double)(correct + wrong) ;
		return accuracy ;
	}

}