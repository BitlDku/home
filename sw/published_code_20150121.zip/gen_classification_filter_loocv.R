#####################################################################
# Test classification accuracy
# filter method test (LOOCV)
#####################################################################

require("e1071")                # for SVM, Naive Bayes
require("class")                # for Knn
library(randomForest)           # for randomForest
######################################################################

#######################################################################
run.classification.filter <- function(fs.list, noFeature, classifier.list) {

    for (i in 1:length(fs.list)) {
        filename = paste("input_", fs.list[i], "_filtered.csv", sep="" )
        whole = read.csv(paste("tmp2/", filename, sep=""))
  
        ds = whole[,-1]
        cl = whole[,1]
  
        noCol = ncol(ds)
        noRow = nrow(ds)
  
        result = matrix(0, nrow=length(classifier.list), ncol=length(noFeature))
  
        # LOOCV --------------------------------------------------
        for (k in 1:noRow) {
  
          test  = rbind(ds[k,]);  clTest = cl[k]
          train = ds[-k,]; clTrain = cl[-k]
  
          scl =  factor(paste("A",cl, sep=""))                 # for SVM
          sclTrain = scl[-k]                                   # for SVM
          sclTest =  scl[k]                                    # for SVM
          levels(sclTrain) <- levels(scl)                      # for SVM
          levels(sclTest) <- levels(scl)                       # for SVM
  
          for (f in 1:length(noFeature)) {
            for (cr in 1:length(classifier.list))  {
               if (classifier.list[cr] == "SVM") {  
                 ## SVM ##
                 model = svm(train[,1:noFeature[f]], sclTrain)
                 if (sclTest == predict(model, test[1,1:noFeature[f]]))
                     result[cr,f] = result[cr,f] + 1
               } else if (classifier.list[cr] == "KNN") {
                
                 if (clTest ==knn(train[,1:noFeature[f]], test[1,1:noFeature[f]],
                                     clTrain, k=5))
                     result[cr,f] = result[cr,f] + 1
               } else if (classifier.list[cr] == "RandomF") {
                 model = randomForest(x=train[,1:noFeature[f]], y=factor(clTrain), proximity=TRUE)
                 if (clTest == predict(model, test[1,1:noFeature[f]]))
                     result[cr,f] = result[cr,f] + 1
              } else if (classifier.list[cr] == "NaiveBayes") {
                 tdata = cbind(scl, sclTrain)
                 model = naiveBayes(scl ~ ., data = tdata)
                 if (sclTest == predict(model, test[1,1:noFeature[f]]))
                     result[cr,f] = result[cr,f] + 1
              }
            } # for (cr)
          } # for(f)
            cat("LOOCV ", k, "/", noRow, "\n")
          # LOOCV end ----------------------------------------------
        } # for(k)
        result = data.frame(result / noRow)
        summ.accuracy = cbind (factor(classifier.list), result)
        names(summ.accuracy) = c("classifier", noFeature)
        print ("classification result (filters)")
        print (summ.accuracy)
  
        out.file = paste("result/output_filter_",fs.list[i],".csv",sep="")
        write.table(summ.accuracy, out.file, sep=",", row.names=FALSE, col.names=TRUE) 
  
    } # for(i)

} # for function
