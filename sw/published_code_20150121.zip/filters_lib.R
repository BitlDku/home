#####################################################################
# Implement Filters  & redundancy removal
# 
#####################################################################
library(FSelector)

#####################################################################
my.entropy = function (vec) {
    probs = table(vec)
    data_length = sum(probs)
    probs = probs/data_length
    return(sum(sapply(probs, function(t) {
        p = as.numeric(t)
        return(-p * log2(p))
    })))
}
#-------------------------------------------------------------------
my.joint.entropy = function (a, b) {
    data_length = length(a)
    probs = as.vector(table(a, b))
    probs = probs/sum(probs)
    return(sum(sapply(probs, function(t) {
        p = as.numeric(t)
        return(if (p == 0) {
            0
        } else {
            -p * log2(p)
        })
    })))
}

## Chi-square #######################################################
my.chisq = function(ds, cl) {
    # ds should be discrete value 
    results = sapply(ds, function(w) {
        cont = table(cl, w)
        row_sums = apply(cont, 1, sum)
        col_sums = apply(cont, 2, sum)
        all_sum = sum(col_sums)
        expected_matrix = t(as.matrix(col_sums) %*% t(as.matrix(row_sums)))/all_sum
        chis = sum((cont - expected_matrix)^2/expected_matrix)
        if (chis == 0 || length(col_sums) < 2 || length(row_sums) < 
            2) {
            return(0)
        }
        else {
            return(sqrt(chis/(all_sum * min(length(col_sums) - 
                1, length(row_sums) - 1))))
        }
    })
    rank.list = order(results, decreasing=TRUE) 
    return(list(ranklist=rank.list,evallist=sort(results, decreasing=TRUE)))
}

## Symmetrical uncertainty ##########################################
my.SU = function(ds, cl) {
    # ds should be discrete value 
    attr_entropies = sapply(ds, my.entropy)
    class_entropy = my.entropy(cl)
    joint_entropies = sapply(ds, function(t) {
        my.joint.entropy(cl, t)
    })
    results = class_entropy + attr_entropies - joint_entropies
    results = 2 * results/(attr_entropies + class_entropy)
    rank.list = order(results, decreasing=TRUE)
    
    return(list(ranklist=rank.list,evallist=sort(results, decreasing=TRUE)))
}

## oneR ########################################################
my.oneR <- function (ds, cl) {
    #new_data = get.data.frame.from.formula(formula, data)
    #new_data = discretize.all(formula, new_data)
    new_data = infotheo::discretize(ds)
    new_data = cbind(factor(cl), new_data)
    class_data = new_data[[1]]
    new_data = new_data[-1]
    results = sapply(new_data, function(vec) {
        vec = factor(vec)
        errors = sapply(levels(vec), function(val) {
            cvaluestab = as.vector(table(class_data[which(vec == 
                val)]))
            return(sum(cvaluestab[-which.max(cvaluestab)])/sum(cvaluestab))
        })
        return(sum(errors))
    })
    results = max(results) + min(results) - results
    rank.list = order(results, decreasing=TRUE)      # oh
    return (list(ranklist=rank.list, evallist=sort(results, decreasing=TRUE)))
    #attr_names = dimnames(new_data)[[2]]
    #return(data.frame(attr_importance = results, row.names = attr_names))
}


## remove redundancy ########################################################
# idea : Efficient Feature Selection via Analysis of Relevance and Redundancy
remove.redundancy <- function(ds, cl, th=0.05) {
   SU = function(X,Y) {
      if ((infotheo::entropy(X)+infotheo::entropy(Y))==0) return(0) 
      su.val = infotheo::mutinformation(X,Y)
      su.val = 2*su.val/(infotheo::entropy(X)+infotheo::entropy(Y))
      return (su.val)
   }
   ods = infotheo::discretize(ds)
   nocol = ncol(ds)
   SU.FC.list = c()
   for (i in 1:nocol) {
      SU.FC.list[i] = SU(ods[,i], cl)
   }
   ranklist = order(SU.FC.list, decreasing=TRUE)
   ods = ods[,c(ranklist)]

   remove.total =0

   ## first deletion
    del.list =c() 
    for (i in 1:(ncol(ods)-1)) {
       if (SU(ods[,i],ods[,i+1])-SU.FC.list[ranklist[i]]> th) {
            del.list = c(del.list,(i+1))
       }
    }
    if (length(del.list)>0) {
       remove.total = remove.total + length(del.list)
       ods = ods[,-c(del.list)]
       ranklist = ranklist[-c(del.list)]
    }   
   ## second deletion
   idx =1 
   while (idx < length(ranklist)) {
      del.list =c() 

      for (i in (idx+1):ncol(ods)) {
         if (SU(ods[,idx],ods[,i])-SU.FC.list[ranklist[i]]> th) {
              del.list = c(del.list, i)
         }
      }
      if (length(del.list)>0) {
         remove.total = remove.total + length(del.list)
         ods = ods[,-c(del.list)]
         ranklist = ranklist[-c(del.list)]
      }   
      idx = idx + 1
   } # end while
   cat("Total removed features: ", remove.total, "\n")
   cat("Total survived features: ", ncol(ds)-remove.total, "\n")
   survive = intersect(c(1:ncol(ds)),ranklist) 
    
   return(survive)

}



