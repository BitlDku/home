#####################################################################
# Merge classification results and 
# suggest best combination of algorithm for given dataset
#####################################################################

run.merge.result <- function(fs.list, fss.list, eval.list, classifier.list, noFeatures) {
   ## Analysis for filtered results ---------------------------------------------
   print("** Result of classification (Filter) ------")
   filter.result = NULL
   for (i in 1:length(fs.list)) {
      in.file = paste("result/output_filter_",fs.list[i],".csv", sep="")
      if (!file.exists(in.file)) {
         cat(filename, "\n") 
         cat("file not exist, \n") 
         next
      }
      whole = data.frame(read.csv(in.file, sep=",", header=TRUE))
      for (k in 1:nrow(whole)) {
         max.idx <- which(whole[k,-1]==max(whole[k,-1]))[1]
         tmp = data.frame(fs.list[i], classifier.list[k], noFeatures[max.idx], whole[k,max.idx+1])
         filter.result = rbind(filter.result, tmp) 
      }
   }
   names(filter.result) = c("filter", "classifer", "#features", "accuracy")
   print (filter.result)
    
   ## Analysis for Wrappered results --------------------------------------------
   print("** Result of classification (Wrapper) -----")
   wraper.result = NULL
#   for (cr in 1:length(fss.list)) cat(fss.list[cr], ",") 
#   cat ("\n")
   for (i in 1:length(fs.list)) {
      in.file = paste("result/output_wrapper_",fs.list[i],".csv", sep="")
      if (!file.exists(in.file)) {
         cat(filename, "\n") 
         cat("file not exist, \n") 
         next
      }
      whole = read.csv(in.file, sep=",", header=TRUE)
      # read no of features -----
      selFeature = matrix(NA, nrow=nrow(whole),ncol=(ncol(whole)-1))
      for (q in 1:length(fss.list)) {
         if (fss.list[q] %in% c("CFS","FCBF")) {
            ds.file = paste("tmp3/input_",fs.list[i],"_",fss.list[q], ".csv", sep="")
            if (!file.exists(ds.file)) next
            tmp.ds = read.csv(ds.file, sep=",", header=TRUE)
            noF = ncol(tmp.ds) - 1
            selFeature[,q] = noF 
         }  else {
            for (r in 1:length(classifier.list)) {
              ds.file = paste("tmp3/input_",fs.list[i],"_",fss.list[q], "_", 
                               classifier.list[r],".csv", sep="")
            if (!file.exists(ds.file)) next
              tmp.ds = read.csv(ds.file, sep=",", header=TRUE)
              noF = ncol(tmp.ds) - 1
              selFeature[r,q] = noF 
            } # for(r)
         }
      } # for(q)
      # merge (selFeature, whole) -> grand
      grand = data.frame(whole[,1])
      for (q in 1:length(fss.list))
        grand = cbind(grand, whole[,q+1], selFeature[,q])
      
      for (k in 1:nrow(whole)) {
         tmp = data.frame(fs.list[i], grand[k,])
         wraper.result = rbind(wraper.result, tmp) 
      }
      
   }
   header = c("filter", "classifer")
   for (q in 1:length(fss.list))
     header = c(header,fss.list[q],"#f")
   names(wraper.result) = header 
   print (wraper.result)

   # write result to file
   sink("result/RESULT_TOTAL.csv", append=FALSE)   # print to file
     print("** Result of classification (Filter) ------")
     print(filter.result)
     print("** Result of classification (wraper) ------")
     print(wraper.result)
   sink()
   
} # end function

