#####################################################################
# 1. Remove irrelevant features 
# 2. Feature evaluation by bootstrap
# 3. Remove redundancy
#####################################################################
source("filters_lib.R")

eval.fs = function(ds, cl, method) {
   eval.list = NULL

   if (method=="Chisq") {                                # Chi-square
     new.ds = discretize(ds) 
     #whole = cbind(cl,new.ds)
     #eval.list <- chi.squared(cl~., whole)
     eval.list <- my.chisq(new.ds,cl)
   } else if (method=="oneR") {                         # oneR
     eval.list <- my.oneR(ds,cl)
   } else if (method=="SU") {                         # SU
     new.ds = discretize(ds) 
     #whole = cbind(cl,new.ds)
     #eval.list <- symmetrical.uncertainty(cl~., whole)
     eval.list <- my.SU(new.ds,cl)
   } else if (method=="MRMR") {                         # MRMR
     # pre filtering -(begin)---------------------
     mi.list = c()
     if (ncol(ds) > 5000) {
        for (i in 1:ncol(ds))
           mi.list[i] = mutinformation(discretize(ds[,i]), cl, method="emp")
        mi.order = order(mi.list, decreasing=TRUE)[1:5000]
        mi.order = mi.order[!is.na(mi.order)]
     } else {
        mi.order = c(1:ncol(ds))
     }
     # pre filtering -(end)---------------------
     set.thread.count(6)                           # use multicore
     cl = cl+1
     new.ds <- mRMR.data(data=cbind(cl,ds[,mi.order]*0.1))
     filter <- mRMR.ensemble(data = new.ds, target_indices = 1, solution_count =1,
                        feature_count = CHOOSE)
     tmp = as.vector(t(solutions(filter)[[1]]))
     tmp <- tmp-1                                 # remove cl column  
     eval.list <- list(ranklist=tmp, evallist=NULL)     
       
   } else if (method=="Relief") {                         # Relief
     # pre filtering -(begin)---------------------
     new.ds = NULL
     if (ncol(ds)>5000) {
	    mi.list = c()
       for (i in 1:ncol(ds))
          mi.list[i] = mutinformation(discretize(ds[,i]), cl, method="emp")
       mi.order = order(mi.list, decreasing=TRUE)[1:5000] 
       new.ds = ds[,mi.order]
     } else {
       new.ds = ds
              } 
     whole = cbind(cl,new.ds)
     weights <- relief(cl~., whole, neighbours.count=5, sample.size=20)
     eval.list = list(ranklist=order(weights, decreasing=TRUE),
                      evallist=sort(t(weights), decreasing=TRUE))      
   } else if (method=="SVM.RFE") {                         # SVM.RFE (subset)
     tmp <- svmrfe(ds, cl)
     eval.list <- list(ranklist=tmp, evallist=NULL)      
 
   } 
   return (eval.list)
}    
#####################################################################

#####################################################################
run.filtering <- function(whole, fs.list) {
  ds = whole[,-1]
  cl = whole[,1]
  
  cat ("Remove irrrelevant features ... \n")
  ## Step 1. remove irrelevant features --------------------------------------
  for (i in 1:length(fs.list)) { 
      cat ("Begin ", fs.list[i], "\n")

      ranklist = eval.fs(ds, cl, method=fs.list[i])$ranklist
      filename = paste("input_",fs.list[i],"_",CHOOSE,".csv", sep="")
      newdata = cbind(cl,ds[,ranklist[1:CHOOSE]])
      write.table(newdata, paste("tmp1/", filename, sep=""), 
               sep=",", row.names=FALSE, col.names=TRUE)
      cat("write", CHOOSE ,"features file :", filename, "\n")         
  }
  
  for (f in 1:length(fs.list)) {  
      
      ## Step 2. feature evaluation by bootstrap ------------------------------
      cat ("feature selection begin : ", fs.list[f], " ---------------- \n") 
      filename = paste("input_",fs.list[f],"_",CHOOSE,".csv", sep="")
      whole2 = read.csv(paste("tmp1/", filename, sep=""),sep=",")
  
      ds2 = whole2[,-1]
                                                                                          
      cl2 = whole2[,1]
      noRow2 = length(cl2)
      noCol2 = ncol(ds2)
      idx = c(1:noRow2)
  
      SAMPLE.SIZE = as.integer(0.8*noRow2)          # for bootstrap
  
      result = matrix(0, nrow=REPEAT, ncol=noCol2)
      
      ## feature evaluation by bootstrap ---------------------------------
   
      for (boost in 1:REPEAT) {
          cat("Repeat= ", boost, "\n")
          choose.sample = sample(idx, SAMPLE.SIZE, replace=FALSE) 
          cur.ds = ds2[c(choose.sample),]
          cur.cl = cl2[c(choose.sample)]
          if (fs.list[f] %in% c("Chisq","oneR","SU", "Relief")) {
             result[boost,] = eval.fs(cur.ds, cur.cl, method=fs.list[f])$evallist
          } else {
            evallist = eval.fs(cur.ds, cur.cl, method=fs.list[f])$ranklist
            new.eval = c()
            for (x in 1:noCol2) new.eval[evallist[x]] = x
            result[boost,] = new.eval
          }   
      }
      # aggregate 
      result.avg = colMeans(result)
      rank.list.ave = c()
      if (fs.list[f] %in% c("Chisq","oneR","SU", "Relief")) {
        rank.list.ave = order(result.avg, decreasing=TRUE)
      } else {
        rank.list.ave = order(result.avg, decreasing=FALSE)
      }
      cat("removing redundant features ..... \n")
      
      filtered.feature =  rank.list.ave
      ## Step 3. remove redundancy -----------------------------------
      if (REMOVE.REDUNDANCY) {
         remove.redundt = c()
         if (fs.list[f] == "MRMR") {     # mrmr
            remove.redundant = rank.list.ave
         } else {
            remove.redundant = remove.redundancy(ds2[,c(rank.list.ave)], cl2, th=TH)
                     }
         filtered.feature =  intersect(rank.list.ave, remove.redundant)
        
      }
      # save data
      filename = paste("input_",fs.list[f],"_filtered",".csv", sep="")
      newdata = cbind(cl2,ds2[,c(filtered.feature)])
      write.table(newdata, paste("tmp2/", filename, sep=""), 
            sep=",", row.names=FALSE, col.names=TRUE)
      
  } # for(f) 
}