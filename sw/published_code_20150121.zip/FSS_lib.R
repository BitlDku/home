#####################################################################
# Feature subset selection 
# 
#####################################################################
library(FSelector)             # forward/backaed/best-first.search
require("e1071")               # for svm
require("class")               # for Knn
library(randomForest)          # for randomForest

BDS <<- NULL
BCL <<- NULL
EVAL.TYPE <<- NULL                     

#####################################################################
# fss.type : (1) forward (2) backward (3) best-first
# eval.type : (1) SVM (2) KNN (3) Random.F
#####################################################################
run.FSS <- function (ids,icl, fss.type, eval.type) {
  BDS <<- ids
  BCL <<- factor(paste("A", icl, sep=""))
  EVAL.TYPE <<- eval.type
  
  subset <- NULL
  if (fss.type == "forward") {
     subset <- forward.search(names(BDS), evaluator)
  } else if (fss.type == "backward") {
     subset <- backward.search(names(BDS), evaluator)
  } else if (fss.type == "best-first") {
     subset <- best.first.search(names(BDS), evaluator)
  }
  flsit = match(subset, names(BDS))

  BDS <<- NULL ; BCL <<- NULL; EVAL.TYPE <<- NULL   # reset
  return(flsit)

}

#####################################################################
evaluator <- function(subset) {
    if (length(subset)==1) return(0)
    #k-fold cross validation
    k <- 10
    splits <- runif(nrow(BDS))

    results = sapply(1:k, function(i) {
      test.idx  <- (splits >= (i - 1) / k) & (splits < i / k)
      train.idx <- !test.idx
      test.ds  <- cbind(BDS[test.idx, subset])
      train.ds <- cbind(BDS[train.idx,subset])
      test.cl  <- BCL[test.idx]
      train.cl <- BCL[train.idx]
      
      error.rate <- NULL
      if (EVAL.TYPE == "SVM") {                               # SVM
          model = svm(train.ds, train.cl)
          error.rate = sum(test.cl != predict(model, test.ds))/nrow(test.ds)
      } else if (EVAL.TYPE == "KNN") {                        # KNN
          error.rate = sum(test.cl != knn(train.ds, test.ds, train.cl))/nrow(test.ds)
      } else if (EVAL.TYPE == "RandomF") {                         # Random Forest
          model =  randomForest(x=train.ds, y=factor(train.cl)) 
          error.rate = sum(test.cl != predict(model, test.ds))/nrow(test.ds)
      } else if (EVAL.TYPE == "NaiveBayes") {                         # NaiveBayes
          tdata = cbind(train.cl, train.ds)
          model = naiveBayes(train.cl ~ ., data = tdata)
          error.rate = sum(test.cl != predict(model, test.ds))/nrow(test.ds)
      }
      return(1 - error.rate)
    })
    #print(subset)
    #print(mean(results))
    return(mean(results))
}

#####################################################################
myFCBF = function (ids,icl) {
  flsit = FCBF(discretize(ids),icl)
  return(flsit)
}
#####################################################################
# c("SVM","KNN","RandomF", "NaiveBayes")
