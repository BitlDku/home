#####################################################################
# Test classification accuracy 
# Wrapper(embedded) method
# LOOCV test
#####################################################################

require("e1071")                # for SVM, Naive Bayes
require("class")                # for Knn
library(randomForest)           # for randomForest
library(rpart)                  # 

######################################################################

run.classification.wrapper <-function(fs.list, fsubset.list, eval.list, classifier.list) {
  
    for (i in 1:length(fs.list)) { 
       result = matrix(0,nrow=length(classifier.list), ncol=length(fsubset.list))         
       for (s in 1:length(fsubset.list)) {
         if (fsubset.list[s] %in% c("CFS", "FCBF")) {  ##################################
            filename = paste("input_", fs.list[i], "_", fsubset.list[s], ".csv", sep="" )
            if (!file.exists(paste("tmp3/", filename, sep=""))) {
              cat(filename, "\n") 
              cat("file not exist, \n") 
              next
            }
            whole = read.csv(paste("tmp3/", filename, sep=""))
            ds = cbind(whole[,-1])
            cl = whole[,1]
    
            noCol = ncol(ds)
            noRow = nrow(ds)
    
            
            # LOOCV --------------------------------------------------
            for (k in 1:noRow) {
              
                test  = rbind(ds[k,]);  clTest = cl[k] 
                train = cbind(ds[-k,]); clTrain = cl[-k]
      
                scl =  factor(paste("A",cl, sep=""))                 # for SVM
                sclTrain = scl[-k]                                   # for SVM
                sclTest =  scl[k]                                    # for SVM
                levels(sclTrain) <- levels(scl)                      # for SVM
                levels(sclTest) <- levels(scl)                       # for SVM
      
                for (cr in 1:length(classifier.list)) {   
                   if (classifier.list[cr] == "SVM") {  
                     ## SVM ##
                     model = svm(train, sclTrain)
                     if (sclTest == predict(model, test[1,]))
                         result[cr,s] = result[cr,s] + 1
                   } else if (classifier.list[cr] == "KNN") {
                    
                     if (clTest ==knn(train, test[1,],
                                         clTrain, k=5))
                         result[cr,s] = result[cr,s] + 1
                   } else if (classifier.list[cr] == "RandomF") {
                     model = randomForest(x=train, y=factor(clTrain), proximity=TRUE)
                     if (clTest == predict(model, test[1,]))
                         result[cr,s] = result[cr,s] + 1
                  } else if (classifier.list[cr] == "NaiveBayes") {
                     tdata = cbind(scl, sclTrain)
                     model = naiveBayes(scl ~ ., data = tdata)
                     if (sclTest == predict(model, test[1,]))
                         result[cr,s] = result[cr,s] + 1
                  }
                } # for(cr)
               cat("LOOCV ", k, "/", noRow, fsubset.list[s], "\n")
            } # for(k)
            # LOOCV end ----------------------------------------------


         } else {   # SFS, SBE, BFS   ##########################################

            for (ev in 1:length(eval.list)) {           
              filename = paste("input_", fs.list[i], "_", fsubset.list[s], "_", 
                                         eval.list[ev], ".csv", sep="" )
      
              if (!file.exists(paste("tmp3/", filename, sep=""))) {
                cat(filename, "\n") 
                cat("file not exist, \n") 
                next
              }
      
              whole = read.csv(paste("tmp3/", filename, sep=""))
              ds = cbind(whole[,-1])
              cl = whole[,1]
      
              noCol = ncol(ds)
              noRow = nrow(ds)
              
              # LOOCV --------------------------------------------------
              for (k in 1:noRow) {
                
                  test  = rbind(ds[k,]);  clTest = cl[k] 
                  train = cbind(ds[-k,]); clTrain = cl[-k]
        
                  scl =  factor(paste("A",cl, sep=""))                 # for SVM
                  sclTrain = scl[-k]                                   # for SVM
                  sclTest =  scl[k]                                    # for SVM
                  levels(sclTrain) <- levels(scl)                      # for SVM
                  levels(sclTest) <- levels(scl)                       # for SVM
        
                  cls.idx <- which(eval.list==eval.list[ev]) 
                  if (eval.list[ev] == "SVM") {
                    model = svm(train, sclTrain)
                    #cat(cls.idx, s, "\n")
                    if (sclTest == predict(model, test[1,]))
                       result[cls.idx,s] = result[cls.idx,s] + 1
                  }
                  if (eval.list[ev] == "KNN") {
                    if (clTest ==knn(train, test[1,], clTrain, k=5))
                       result[cls.idx,s] = result[cls.idx,s] + 1
                  }
                  if (eval.list[ev] == "RandomF") {
                    ## Random Forest
                    model = randomForest(x=train, y=factor(clTrain))
                    if (clTest == predict(model, test[1,]))
                       result[cls.idx,s] = result[cls.idx,s] + 1
                  }
                  if (eval.list[ev] == "NaiveBayes") {
                    tdata = cbind(scl, sclTrain)
                    model = naiveBayes(scl ~ ., data = tdata)
                    if (clTest == predict(model, test[1,]))
                       result[cls.idx,s] = result[cls.idx,s] + 1
                  }
                  cat("LOOCV ", k, "/", noRow, fsubset.list[s], "\n")
              } # for(k)
         } # for(ev)
       }   #######################################################################
      } # for(s)  
        result = data.frame(result / noRow)
        summ.accuracy = cbind (classifier.list, result)
        names(summ.accuracy) = c("classifier", fsubset.list)
        print ("classification result (wrappers)")
        print (summ.accuracy)
  
        out.file = paste("result/output_wrapper_",fs.list[i],".csv",sep="")
        write.table(summ.accuracy, out.file, sep=",", row.names=FALSE, col.names=TRUE) 
    } # for(i)
}

