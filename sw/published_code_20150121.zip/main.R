#####################################################################
# Procedure for finding biomarker genes
#
# 1. Remove irrelevant features  
# 2. Evaluate features and generate rank list (by bootstrap)
# 3. Remove redundancy
# update : 2015.01.19
#####################################################################

require(FSelector)              # for chiSq, Relief, CFS
require(mRMRe)                  # for mrmr
require(infotheo)               # discretize, entropy, mutual information

########################################################################
# Set program directory & load required library
########################################################################
setwd("D:/biomarker/published_code") 
source("filters_lib.R")          # for chi-sq, oneR, SU, remove.redundancy
source("SVM_RFE_lib.R")          # for svm.rfe
source("gen_filtering.R")        # for running step 1,2,3
source("gen_feature_subset.R")   # for running step 4
source("gen_classification_filter_loocv.R")       # for running step 5
source("gen_classification_wrapper_loocv.R")      # for running step 5
source("gen_merge_result.R")                      # merge classification result

########################################################################
# Select algorithms you want to test
########################################################################
# Feature selection : 
# c("Chisq","oneR","SU", "MRMR","Relief","SVM.RFE")
fs.list = c("Chisq", "SVM.RFE")
# Feature subset selection : 
# c("forward","backward","best-first", "CFS", "FCBF")
fss.list = c("best-first", "FCBF")
# classification algorithms : 
# c("SVM","KNN","RandomF", "NaiveBayes")
classifier.list = c("SVM","KNN")
eval.list = classifier.list

########################################################################
# Set parameters
########################################################################
CHOOSE <<- 1000                # no of features after memoving irrelevant features
REPEAT <<- 20                  # times of re-sampling
REMOVE.REDUNDANCY <<- TRUE     # perform redundancy removal only when 'TRUE'
TH <<- 0.05                    # threshold value for redundancy removal
NO.FEATURES = c(5,10,15,20,25,30,35,40)  # no of features that we want to test in classification (MSC)

########################################################################
# Load microarray dataset
########################################################################
whole = read.csv("D:/biomarker/datasets/GDS3715.csv",head=FALSE)

########################################################################
# Begin procedure for finding biomarker
########################################################################
dir.create("tmp1",showWarnings=FALSE)
dir.create("tmp2",showWarnings=FALSE)
dir.create("tmp3",showWarnings=FALSE)
dir.create("result",showWarnings=FALSE)

run.filtering(whole, fs.list)            # pre-filtering, feature evaluation, redundancy removal
run.fss(fs.list, fss.list, eval.list)    # feature subset selection
run.classification.filter(fs.list, NO.FEATURES,classifier.list)                # classification 
run.classification.wrapper(fs.list, fss.list, eval.list, classifier.list)      # classification 
run.merge.result(fs.list, fss.list, eval.list, classifier.list,NO.FEATURES)    # merge classification result  
  

