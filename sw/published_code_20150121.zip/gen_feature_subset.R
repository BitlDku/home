#####################################################################
# Generate feature subset
# by BFS_CFS, BFS_SVM, BFS_KNN, FCBF, GA
#
#####################################################################

require(FSelector)               # for chiSq, Relief, CFS
library(infotheo)                # discretize, entropy, mutual information

source("FSS_lib.R")              # Feature subset selection 
source("CFS_lib.R")              # CFS
source("FCBF_lib.R")             # FCBF

#####################################################################
eval.fss = function(ds, cl, method, evalf) {
   flist = NULL

   if (method=="CFS") {                            # CFS
     flist =  my.cfs(cl~., cbind(cl,ds))
   } else if (method=="FCBF") {                    # FCBF
     flist = myFCBF(ds,cl)
   } else {
     flist = run.FSS(ds,cl, method, evalf)
   }
   return (flist)
}                     

#####################################################################
run.fss <- function(fs.list, fss.list, eval.list) {
  
    for (i in 1:length(fs.list)) { 
       cat("Begin feature subset selection ", fs.list[i], "\n" ) 
       whole = read.csv(paste("tmp2/input_", fs.list[i],"_filtered.csv", sep=""))
      
       ds = whole[,-1]
       cl = whole[,1]
   
       for (s in 1:length(fss.list)) {
          for (e in 1:length(eval.list)) {
            sel.list = eval.fss(ds, cl, method=fss.list[s], evalf=eval.list[e])         
            newdata = cbind(cl,ds[,sel.list])
            filename = NULL 
            if (fss.list[s] %in% c("CFS","FCBF")) {
               filename = paste("input_", fs.list[i], "_", fss.list[s], ".csv", sep="" )
            } else {
               filename = paste("input_", fs.list[i], "_", fss.list[s], "_", eval.list[e],".csv", sep="" )
            }
            write.table(newdata, paste("tmp3/", filename, sep=""), 
                     sep=",", row.names=FALSE, col.names=TRUE)
             cat("Write:", filename, "\n") 
          } # for (e)
       } # for(s)       
    } # for(i)
}

