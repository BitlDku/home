#############################
#		FCBF  
#   modified by OH
#############################
    
library(infotheo)              # entropy, mutual information

## Function symmetrical.uncertainty  ######################################
sym.uncertainty = function (X,Y) {
   hx = infotheo::entropy(X, method="emp")
   hy = infotheo::entropy(Y, method="emp")
   mi = infotheo::mutinformation(X, Y, method="emp")
   su.value =  2*(mi/(hx+hy))
   return (su.value)
}
##########################################################################

## Function flitering irrelavant feature  ################################
filter.irrelavant = function (DS,CL) {
   nocol = ncol(DS)
   noChoose = as.integer(log(nocol)*sqrt(nocol))
   DDS = discretize(DS, disc="equalwidth", nbins=10)
   su = c()
   for (i in 1:nocol) {
     su[i] = sym.uncertainty(DDS[,i], CL)
   }
   filtered = order(su, decreasing = TRUE)[1:noChoose]
  
   return (filtered)
}
##########################################################################


## FCBF ##################################################################
FCBF = function (ds, cl) {
    noCol = ncol(ds)      
    weights = c(rep(0,noCol)) 
    for (i in 1:noCol) {
        weights[i] = sym.uncertainty(cl, ds[,i])
    }
    names(weights) = names(ds)
    wlist = names(ds)
    
    # sort & filter irelavant features -------------------------
    nsel = as.integer(sqrt(noCol)*log(noCol))
    weights = sort(weights, decreasing = TRUE)
    subset = weights[1:nsel]
  

    # make filtered dataset  -----------------------------------
    newdata<-ds[,names(subset)]
    newdata = cbind(newdata, cl)
    
    dNum = ncol(newdata)-1
    
    p = 1
    while (p < (dNum-1)) {
      q = p+1 ; delList =c()
    	while (q <= dNum) {
        SUpq = sym.uncertainty (newdata[,p], newdata[,q]) 
 	      SUqc = sym.uncertainty (newdata[,q], cl)
    		if(SUpq >= SUqc){
    		    delList = c(delList, q) 
    		}
  #      cat("p,q ", SUpq, ",", SUqc, "\n")
  #      cat("delList ", delList, "\n")
         
    		q = q+1
    	} # end q
    	p = p+1
      if (!is.null(delList)) newdata = newdata[,-delList] 
      dNum = ncol(newdata)-1
      #if (dNum <= p) break
    } # end p
   
    flist = c()
    for (i in 1:(length(newdata)-1)) {
       flist[i] = which(wlist==names(newdata)[i])
    }
    #return (names(newdata)[-length(newdata)])                  
    return (flist)                  
}
##########################################################################

## FCBF ##################################################################
# using threshold
FCBF2 = function (ds, cl, th=0.8) {
    noCol = ncol(ds)                  
    weights = c(rep(0,noCol)) 
    for (i in 1:noCol) {
        weights[i] = sym.uncertainty(cl, ds[,i])
    }
    names(weights) = names(ds)
    
    # sort & filter irelavant features -------------------------
    nsel = as.integer(sqrt(noCol)*log(noCol))
    weights = sort(weights, decreasing = TRUE)
    subset = weights[1:nsel]
  

    # make filtered dataset  -----------------------------------
    newdata<-ds[,names(subset)]
    newdata = cbind(newdata, cl)
    
    dNum = ncol(newdata)-1
    
    p = 1
    while (p < (dNum-1)) {
      q = p+1 ; delList =c()
    	while (q <= dNum) {
        SUpq = sym.uncertainty (newdata[,p], newdata[,q]) 
 	      #SUqc = sym.uncertainty (newdata[,q], cl)
    		if(SUpq >= th){
    		    delList = c(delList, q) 
    		}
  #      cat("p,q ", SUpq, ",", SUqc, "\n")
  #      cat("delList ", delList, "\n")
         
    		q = q+1
    	} # end q
    	p = p+1
      if (!is.null(delList)) newdata = newdata[,-delList] 
      dNum = ncol(newdata)-1
      #if (dNum <= p) break
    } # end p
    
    return (names(newdata)[-length(newdata)])
}
##########################################################################

