#' Create a feature interaction table
#'
#' This function create a feature interaction table.
#'
#' @param model A prediction model (Classification or regression)
#' @param train Training dataset (data frame) that is used to building model
#' @param target.name Name of target label name in train dataset
#' @param itr Number of experiments. Default is 50
#' @param task Prediction task. "regression" (default) or "classification".
#' @param class class name (for classification model)
#' @return [list] feature interaction & feature importance table
#' @examples
#' library("CBFI")
#' # for regression
#' data("Boston", package = "MASS")
#' model <- lm(medv ~ ., data = Boston)
#' FIobj1 <- FItable(model, train=Boston, target.name="medv", grid=50,
#'                  task="regression", interaction_type="OH2")
#' print(FIobj1)
#'
#' # for classification
#' library(e1071)
#' model2 <- svm(Species~., data=iris)
#' FIobj2 <- FItable(model2, train=iris, target.name="Species", grid=50,
#'                  task="classification", interaction_type="OH2", all.class=F)
#' print(FIobj2)
#'
#' @export
CB_FItable <- function(model, train, target.name, itr=50, task="regression",
                    class="_all_") {
  # error handling
  if (!(task %in% c("regression", "classification"))) {
    print("task should be one of regression', 'classification'")
    return(NULL)
  }
  if(task=="classification") {
    cname <- c(unique(train[, target.name]), "_all_")
    if(!(class %in% cname)) {
      print("Error. class name is wrong!"); return(NULL)
    }
  }

  train2 <- train[,-which(names(train)==target.name)]
  cl <-  train[,target.name]

  ## Get pairwise interaction value ------------------------------------------
  cl.names <- names(train2)
  cbn <- combn(cl.names,2)

  tmp <- CB_FeatureInteract(model, train, target.name, F1=cbn[1,1], F2=cbn[2,1], itr=itr, task=task)
  interact <- tmp$data


  if (ncol(cbn) >= 2 )
    for (i in 2:ncol(cbn)) {
       tmp <- CB_FeatureInteract(model, train, target.name, F1=cbn[1,i], F2=cbn[2,i], itr=itr, task=task)
       interact <- rbind(interact, tmp$data)
    }

  myint <- interact[,1:4]

  names(myint) <- c("class", "from", "to", "weight")


  ## Get feature importance --------------------------------------------------
  imp <- CB_FeatureImp(model, train, target.name, itr=itr, task=task)
  myimp <- data.frame(imp$importance[,1:3])
  names(myimp) <- c("class","feature", "importance")

  myint$weight <- round(myint$weight, 3)
  myimp$importance <- round(myimp$importance, 3)

  return(list(Fint=myint, Fimp=myimp))
}

