/************************************************************************************
dkuCH_Concaveness

	- Options	:	
		-p  using original data file 
		-f  using existing convex list file
	
	- Input  : 
		(1) dataset 
		(2) Convex hull points List

	- Output : 
		(1) dataset (if row is included in vetexes of concave hull, change the flag colum to 1 )
		(2) Concave hull points List

	- default setting 
             (1) NO_OF_DIM	:	dimension of dataset, number of features
			 (2) N				:	threshhold for digging 
**************************************************************************************/

import java.io.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.StringTokenizer;

class dkuCH_Concaveness 
{
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	static String dataSetFile = "";                // input
	static String cvxListFile = "";                 // input
	static String ccvDataSetFile = "";         // output
	static String ccvListFile = "";                   // output


	static int NO_OF_DIM = 2;                              // dimension of data
	static double N = 1.0;                                 // threshold for digging
	
	static boolean set_N = false;
	
	double [][] orgData ;
	double [] classCenter ;
	
	double value_cm=0;
	
	int [] boldComponent = null;
	
	ArrayList<int []> cvxList = new ArrayList<int []>();	//convex list. it will be concave list after finding concave hull.
	ArrayList<int []> backup_cvxList = new ArrayList<int []>();	//backup_convex list for comparing with concave hull.
	ArrayList<Double> concaveness_graph  = new ArrayList<Double>();
	ArrayList<int []> OriginalCvxList = new ArrayList<int []>();
	ArrayList<Double> cvxCal = new ArrayList<Double>();
	ArrayList<Integer> changedComponent = new ArrayList<Integer>();
	
	ArrayList<double []> nvList = new ArrayList<double []>();

	
	/*///////////////////////////////////////////////////////////////////////////////////////////
	Find Opposite point during digging (OH)
	///////////////////////////////////////////////////////////////////////////////////////////*/
	public double [] findOppositePoint(int idxOldComponent, int idxNewComponent)
	{
		double [] oppositePoint ;
		int [] oldComponent =  boldComponent;
		int [] newComponent = (int [])cvxList.get(idxNewComponent); 

		int [] flag	= new int [NO_OF_DIM];

		for (int n=0; n<NO_OF_DIM; n++)
			for (int m=0; m<NO_OF_DIM; m++)
				if (newComponent[m] == oldComponent[n])
					flag[n] = 1;
		int idxOpposite = -1;
		for (int n=0; n<NO_OF_DIM; n++)
			if (flag[n] == 0)
				idxOpposite = n;

		oppositePoint = orgData[oldComponent[idxOpposite]-1];

		return oppositePoint;
	}
	
	
	/*///////////////////////////////////////////////////////////////////////////////////////////
	Calculate Center point of given class(OH)
	///////////////////////////////////////////////////////////////////////////////////////////*/
	public void calcClassCenter()
	{
		classCenter = new double [NO_OF_DIM];
		double [] tmpRecoed = new double [NO_OF_DIM];

		for (int i=0; i<orgData.length; i++)
			for (int j=0; j<NO_OF_DIM; j++)
				tmpRecoed[j] += orgData[i][j];

		for (int i=0; i<NO_OF_DIM; i++)
			classCenter[i] = tmpRecoed[i]/orgData.length;
	}
	
	/*///////////////////////////////////////////////////////////////////////////////////////////
	Calculate normal vectors for cvxList edges (OH)
	///////////////////////////////////////////////////////////////////////////////////////////*/
	public void makeCvxNormalVector()
	{
		// AX = Y    (X is normal vector
		double [] X = new double[NO_OF_DIM];	

		Simeq sq = new Simeq(); 
		for (int i=0; i<cvxList.size(); i++){

			X = calcOneNormalVector(i, 1);

			//take innervector
			int [] getItem = (int [])cvxList.get(i);
			double [] componentCenter = new double [NO_OF_DIM];  

			for (int k=0; k<NO_OF_DIM; k++)
				for (int j=0; j<NO_OF_DIM; j++)
				{
					componentCenter[j] += orgData[getItem[k]-1][j];
				}

			for (int j=0; j<NO_OF_DIM; j++)
			{
				componentCenter[j] /= NO_OF_DIM;
			}

			double [] insideVector = new double [NO_OF_DIM];
			for (int j=0; j<NO_OF_DIM; j++)
			{
				insideVector[j] = classCenter[j] - componentCenter[j];
			}

			if (calcAngle(X, insideVector)> 0) // direction of normal vector is inside convex 
			{
				X = calcOneNormalVector(i, -1);
			}

			nvList.add(X);
		}
	} 
	
	/*///////////////////////////////////////////////////////////////////////////////////////////
	Calculate Normal vector for a component (OH)
	///////////////////////////////////////////////////////////////////////////////////////////*/

	public double [] calcOneNormalVector(int componentNo, int direction)
	{
		// AX = Y    (X is normal vector
		double [][] A = new double[NO_OF_DIM][NO_OF_DIM];
		double [] Y = new double[NO_OF_DIM];
		double [] X = new double[NO_OF_DIM];	

		for (int i=0; i<NO_OF_DIM; i++)
			Y[i] = direction ;

		Simeq sq = new Simeq(); 
		for(int k=0; k<NO_OF_DIM; k++){
			 for (int j=0; j<NO_OF_DIM; j++){
				  int [] getRecord = (int [])cvxList.get(componentNo);
				  int rowVal = getRecord[k];
				  A[k][j] = orgData[rowVal-1][j];
			 }
		}
				
		sq.Simeqation(A, Y, X);   // Normal vector �� ��ǥ���� X �� ����Ǿ� return �ȴ�.  

		return X ;

	}
	
	/*///////////////////////////////////////////////////////////////////////////////////////////
	Calculate angle between two vectors (OH)
	///////////////////////////////////////////////////////////////////////////////////////////*/

	public double calcAngle(double [] vectorA, double [] vectorB)
	{
		double angle =0;
		
		double normA = 0, normB =0, innerProduct =0; 
		for (int i=0; i<NO_OF_DIM; i++)
		{
			normA += Math.pow(vectorA[i],2);
			normB += Math.pow(vectorB[i],2);
			innerProduct += vectorA[i]*vectorB[i];
		}
		normA = Math.sqrt(normA); 	normB = Math.sqrt(normB);
		angle = innerProduct / (normA * normB );

		return angle;
	}	
	
	/*///////////////////////////////////////////////////////////////////////////////////////////
	Calculate Euclidean distance between point A and B(OH) 20100626
	///////////////////////////////////////////////////////////////////////////////////////////*/
	public double calcEDistance(double [] pointA, double [] pointB)
	{
		double dist = -1;
		double tmpDistance =0;
		for (int i=0; i<NO_OF_DIM; i++)
			tmpDistance += Math.pow(pointA[i]-pointB[i],2);

		dist = Math.sqrt(tmpDistance);
		return dist;
	}
	
	/*///////////////////////////////////////////////////////////////////////////////////////////
	Calculate distance between point A and component B(OH) 20100626
	///////////////////////////////////////////////////////////////////////////////////////////*/
	public double calcPCDistance(double [] pointA, int idxComponentB)
	{
		double dist = -1;

		int getRecord [] = (int [])cvxList.get(idxComponentB);  

		switch (NO_OF_DIM)
		{
			case 2:  ////////////////////////////////////////////////////////////////////// 2-Dimensional 
				double x0 = pointA[0], y0 = pointA[1];                                     // pa 
				double x1 = orgData[getRecord[0]-1][0], y1 = orgData[getRecord[0]-1][1] ;  // sa
				double x2 = orgData[getRecord[1]-1][0], y2 = orgData[getRecord[1]-1][1] ;  // sb

				double a,b,c,t;
				a = Math.pow(x1-x0,2) + Math.pow(y1-y0,2);          // SQDS(sa,pa);
				b = Math.pow(x2-x0,2) + Math.pow(y2-y0,2);          // SQDS(sb,pa);
				c = Math.pow(x1-x2,2) + Math.pow(y1-y2,2);          // SQDS(sa,sb);

				if (a<b)
				{
					double tmp=a; a=b; b=tmp;
				}
				if (a > b+c || c < 0.000000001)          // �а��̶��
				{
					dist = Math.sqrt(b);
				} else {  				             // �����̶��
					//t=sa.x*sb.y-sb.x*sa.y+sb.x*pa.y-pa.x*sb.y+pa.x*sa.y-sa.x*pa.y;
					t = x1*y2 - x2*y1 + x2*y0 - x0*y2 + x0*y1 - x1*y0;
					dist = (double)Math.abs(t)/(double)Math.sqrt(c);
				}
				return dist; 
				//break;

			// case 3:   ////////////////////////////////////////////////////////////////////// 3-Dimensional
				// Implement later
				// break;
			default : ////////////////////////////////////////////////////////////////////// n-Dimensional (n>3)

				// find nearest edge point ------------------------------------------------
				int idxNearEdgePoint = -1;
				double minDistance = 999999;

				for (int m=0; m<NO_OF_DIM; m++)
				{
					double tmpDistance = calcEDistance(pointA, orgData[getRecord[m]-1]);
					if ( tmpDistance< minDistance)
					{
						minDistance = tmpDistance;
						idxNearEdgePoint = getRecord[m];
					}
				}
				double [] nearEdgePoint = orgData[idxNearEdgePoint-1];

				// find opposite mid point of nearEdgePoint ------------------------------------------
				double [] oppositeMidPoint = new double [NO_OF_DIM];

				for (int n=0; n<NO_OF_DIM; n++)
				{
					if (getRecord[n]== idxNearEdgePoint)
						continue;
					for (int m=0; m<NO_OF_DIM; m++)
						oppositeMidPoint[m] +=   orgData[getRecord[n]-1][m];
				}

				for (int m=0; m<NO_OF_DIM; m++)
					oppositeMidPoint[m] /= (NO_OF_DIM-1);

				// find inside point of Component ------------------------------------------
				double edgeLength = calcEDistance(pointA,  oppositeMidPoint);
				double [] minusFactor = new double [NO_OF_DIM];

				for (int m=0; m<NO_OF_DIM; m++)
					minusFactor[m] = ((nearEdgePoint[m] - oppositeMidPoint[m])/edgeLength) * 0.1;

				double [] insidePoint = new  double [NO_OF_DIM];
				for (int m=0; m<NO_OF_DIM; m++)
					insidePoint[m] = nearEdgePoint[m] - minusFactor[m];
						
				// claculate distance ------------------------------------------
				dist = calcEDistance(pointA, insidePoint);		

		}

		return dist;
	}

	/*///////////////////////////////////////////////////////////////////////////////////////////
	Count instances of dataset.
	///////////////////////////////////////////////////////////////////////////////////////////*/
	public int countInstance(String targetFile)
	{
		int cnt =0;
		String s1;
		try {
			BufferedReader in = new BufferedReader(new FileReader(targetFile));
			int i = 0; 
			while ((s1 = in.readLine()) != null)
			{
				cnt++;
			}

			in.close();
		} catch (IOException IOe) {
			System.err.println(IOe);
			System.exit(1);
		}
		return cnt;
	}	
	
	
	/*////////////////////////////////////////////////////////////////////////////////////////////
	Load original data from data file
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public void loadOriginalData()
	{
		// Original data
		orgData = new double[countInstance(dataSetFile)][NO_OF_DIM+1];    // +1, to add flag field

		String s1;
		try {
			BufferedReader in = new BufferedReader(new FileReader(dataSetFile));
			int i = 0; 
			while ((s1 = in.readLine()) != null)
			{
				StringTokenizer token = new StringTokenizer(s1, ",");
				for (int j=0; j<NO_OF_DIM; j++)
				{
					orgData[i][j] = Double.parseDouble(new BigDecimal(Double.parseDouble(token.nextToken().trim())).setScale(4, BigDecimal.ROUND_HALF_UP).toString());
				}
				i++;
			}
			in.close(); 

		} catch (IOException IOe) {
			System.err.println(IOe);
			System.exit(1);
		}
	}
	
	/*////////////////////////////////////////////////////////////////////////////////////////////
	Load original data from data file
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public int load_CountFeature()
	{
		// Original data
		orgData = new double[countInstance(dataSetFile)][NO_OF_DIM+1];    // +1, to add flag field

		String s1, s2;
		int count=0;
		try {
			BufferedReader in = new BufferedReader(new FileReader(dataSetFile));
			if ((s1 = in.readLine()) != null){
			
				StringTokenizer token = new StringTokenizer(s1, ",");
			
				while (token.hasMoreElements())
				{	
					token.nextToken();
					count++;
				}
			}
			in.close(); 
		} catch (IOException IOe) {
			System.err.println(IOe);
			System.exit(1);
		}
		return count;
	}

	/*////////////////////////////////////////////////////////////////////////////////////////////
	Load convex list from file. 
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public void loadConvexList()
	{
		// Read cvxList file --------------------------------------------------------------- 
		String s1;
		try {
			BufferedReader in = new BufferedReader(new FileReader("tmp/"+cvxListFile));
			int numbering = 1;
			while ((s1 = in.readLine()) != null)
			{
				StringTokenizer token = new StringTokenizer(s1, ",");
				int tmpRecord [] = new int[NO_OF_DIM+1];
				int tmpRecord_ccv [] = new int[NO_OF_DIM+1];
				for (int j=0; j<NO_OF_DIM; j++)
				{
					int t = Integer.parseInt(token.nextToken().trim());
					tmpRecord[j] = t;
					tmpRecord_ccv[j] = t;
				}
				tmpRecord[NO_OF_DIM] = numbering;
				cvxList.add(tmpRecord);
				numbering++;
				OriginalCvxList.add(tmpRecord_ccv);
			}
			in.close(); 
		} catch (IOException IOe) {
			System.err.println(IOe);
			System.exit(1);
		}
	}

	
	/*////////////////////////////////////////////////////////////////////////////////////////////
	Turn on the flag of vertex via convex list.
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public void flagVertexPoints()
	{
		int getRecord [];
		for (int i=0; i<cvxList.size(); i++)
		{
			getRecord = cvxList.get(i);
			for (int j=0; j < NO_OF_DIM; j++)
			{
				orgData[getRecord[j]-1][NO_OF_DIM] = 1;	// set flag field to 1
			}
		}
	}
	

	/*////////////////////////////////////////////////////////////////////////////////////////////
	Convert format of original data.
	qhull(qconvex.exe) dose not use comma for delimiter.
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public void convertFormat_Origin(){
		// Read file (using comma) --------------------------------------------------------------- 
		String s1;
		double tmpRecord [][]= null ;
		int count =0;
		int i=0;
		try {
			BufferedReader in = new BufferedReader(new FileReader(dataSetFile));
			count = countInstance(dataSetFile);
			tmpRecord = new double[count][NO_OF_DIM];	
			while ((s1 = in.readLine()) != null)
			{
				StringTokenizer token = new StringTokenizer(s1.trim(), ","); // delimiter is comma
					for (int j=0; j<NO_OF_DIM; j++)
					{
						tmpRecord[i][j] = Double.parseDouble(new BigDecimal(Double.parseDouble(token.nextToken().trim())).setScale(4, BigDecimal.ROUND_HALF_UP).toString());
					}
				i++;
			}
			in.close();
		} catch (IOException IOe) {
			System.err.println(IOe);
			System.exit(1);
		}
		
		// Save converted file (using space)
		try {
			FileWriter   fw_1 = new FileWriter("tmp/"+dataSetFile + "_converted");
			BufferedWriter bw_1 = new BufferedWriter(fw_1);
			PrintWriter outFile_1 = new PrintWriter(bw_1);
			outFile_1.print(NO_OF_DIM);
			outFile_1.println(""); 
			outFile_1.print(count);
			outFile_1.println(""); 
			for (i=0; i<count; i++)
			{
				for (int j=0; j<NO_OF_DIM; j++)
				{
					outFile_1.print(tmpRecord[i][j]+"  ");  // delimiter is space
				}
				outFile_1.println("");  
			}
			outFile_1.close(); 
		} catch (IOException IOe) {
			System.err.println(IOe);
			System.exit(1);
		}
	}
	/*////////////////////////////////////////////////////////////////////////////////////////////
	Convert format of result
	Because results of qhull(qconvex.exe) use space for delimiter. 
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public void convertFormat_Result()
	{
		// Read result file --------------------------------------------------------------- 
		String s1;
		int tmpRecord [][]= null ;
		int count =0;
		int i=0;
		try {
			BufferedReader in = new BufferedReader(new FileReader("tmp/result_"));
			count = Integer.parseInt(in.readLine().trim());
			tmpRecord = new int[count][NO_OF_DIM];	
			while ((s1 = in.readLine()) != null)
			{
				StringTokenizer token = new StringTokenizer(s1.trim(), " "); // delimiter is space
					for (int j=0; j<NO_OF_DIM; j++)
					{
						tmpRecord[i][j] = Integer.parseInt(token.nextToken().trim());
					}
				i++;
			}
			in.close();
		} catch (IOException IOe) {
			System.err.println(IOe); // ������ �ִٸ� �޽��� ���
			System.exit(1);
		}
		
		// Save converted result
		try {
			FileWriter   fw_1 = new FileWriter("tmp/Result");   
			BufferedWriter bw_1 = new BufferedWriter(fw_1);   
			PrintWriter outFile_1 = new PrintWriter(bw_1);      
			for (i=0; i<count; i++)
			{
				for (int j=0; j<NO_OF_DIM; j++)
				{
					// delimiter is comma and INDEX VALUE START AT 1. therefore plus 1 to tmpRecord value.
					outFile_1.print((tmpRecord[i][j]+1) + ", ");   
				}
				outFile_1.println("");  
			}
			outFile_1.close(); 
		} catch (IOException IOe) {
			System.err.println(IOe);
			System.exit(1);
		}
		
	}
	
	
	/*////////////////////////////////////////////////////////////////////////////////////////////
	Make convex hull list through qhull program.
	Result is saved in 'tmp' diriectory.
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public void makeConvexList()
	{
		Runtime oRuntime = Runtime.getRuntime();
		Process oProcess;
		try { // Call qconvex program with options. 
			File f = new File("tmp");
			f.mkdirs();
			oProcess = oRuntime.exec("cmd /c qconvex.exe i Qt TI "+"tmp/"+dataSetFile + "_converted"+" TO tmp/result_");
			BufferedReader stdOut = new BufferedReader(new InputStreamReader(oProcess.getInputStream()));
			String s = "";
			while((s= stdOut.readLine()) != null) {
				System.out.println(s);
			}	
		} catch (IOException e) {
			// Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*////////////////////////////////////////////////////////////////////////////////////////////
	Calculate total length of components of concave hull.
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public double calcCcvLength()
	{
		double totalEdgeLength =0;
		for (int i=0; i<cvxList.size(); i++)
		{
			double avgEdgeLength =0;
			int cCnt = 0;
			int getRecord [] = (int [])cvxList.get(i);  

			int[] indices;
			CombinationGenerator cg = new CombinationGenerator (NO_OF_DIM, 2);
			StringBuffer combination;
			while (cg.hasMore())
			{
				combination = new StringBuffer ();
				indices = cg.getNext ();

				int x = getRecord[indices[0]]; 
				int y = getRecord[indices[1]]; 

				double tmpLength =0;
				for (int k=0; k<NO_OF_DIM; k++)
					tmpLength += Double.parseDouble(new BigDecimal(Math.pow(orgData[x-1][k]-orgData[y-1][k], 2)).setScale(4, BigDecimal.ROUND_HALF_UP).toString());	
				tmpLength = Double.parseDouble(new BigDecimal(Math.sqrt(tmpLength)).setScale(4, BigDecimal.ROUND_HALF_UP).toString());
				
				avgEdgeLength += tmpLength;
				cCnt++;
			}
			
			avgEdgeLength = Double.parseDouble(new BigDecimal(  avgEdgeLength / (double)cCnt   ).setScale(4, BigDecimal.ROUND_HALF_UP).toString());
			
			cvxCal.add(avgEdgeLength);
			totalEdgeLength += avgEdgeLength;
		}
		return Double.parseDouble(new BigDecimal(   totalEdgeLength  ).setScale(4, BigDecimal.ROUND_HALF_UP).toString());	
		
	}
	
	/*////////////////////////////////////////////////////////////////////////////////////////////
	Calculate total length of components of convex hull.
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public double calcCvxLength()
	{
		double totalEdgeLength =0;
		for (int i=0; i<backup_cvxList.size(); i++)
		{
			double avgEdgeLength =0;
			int cCnt = 0;
			int getRecord [] = (int [])backup_cvxList.get(i);  

			int[] indices;
			CombinationGenerator cg = new CombinationGenerator (NO_OF_DIM, 2);
			StringBuffer combination;
			while (cg.hasMore())
			{
				combination = new StringBuffer ();
				indices = cg.getNext ();

				int x = getRecord[indices[0]]; 
				int y = getRecord[indices[1]]; 

				double tmpLength =0;
				for (int k=0; k<NO_OF_DIM; k++)
					tmpLength += Double.parseDouble(new BigDecimal(Math.pow(orgData[x-1][k]-orgData[y-1][k], 2)).setScale(4, BigDecimal.ROUND_HALF_UP).toString());
				
				
				tmpLength = Double.parseDouble(new BigDecimal(Math.sqrt(tmpLength)).setScale(4, BigDecimal.ROUND_HALF_UP).toString());
				
				avgEdgeLength += tmpLength;
				cCnt++;
			}
			
			avgEdgeLength = Double.parseDouble(new BigDecimal(  avgEdgeLength / (double)cCnt   ).setScale(4, BigDecimal.ROUND_HALF_UP).toString());
			
			cvxCal.add(avgEdgeLength);
			totalEdgeLength += avgEdgeLength;
		}
		return Double.parseDouble(new BigDecimal(   totalEdgeLength  ).setScale(4, BigDecimal.ROUND_HALF_UP).toString());	
		
	}
	
	/*////////////////////////////////////////////////////////////////////////////////////////////
	Calculate concaveness measure value.
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public void calcCM()
	{
		value_cm =( this.calcCcvLength() - this.calcCvxLength() ) / this.calcCcvLength() ;
		System.out.println(this.calcCcvLength());
		System.out.println(this.calcCvxLength());
		System.out.println(value_cm);
	}
	
	
	/*////////////////////////////////////////////////////////////////////////////////////////////
	Concave Hull Algorithm
	Dig the boundary as a result of comparing between nearest inner point and decision distance.
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public void findConcave()
	{
		backup_cvxList.addAll(cvxList);
		System.out.println("Work is start --------------- "+cvxList.size());
		for (int i=0; i<cvxList.size(); i++)
		{
			// Step. 0 Calculate average of edges of each component
			double avgEdgeLength =0;
			int cCnt = 0;
			int getRecord [] = (int [])cvxList.get(i);  

			int[] indices;
			CombinationGenerator cg = new CombinationGenerator (NO_OF_DIM, 2);
			StringBuffer combination;
			while (cg.hasMore())
			{
				combination = new StringBuffer ();
				indices = cg.getNext ();

				int x = getRecord[indices[0]]; 
				int y = getRecord[indices[1]]; 

				double tmpLength =0;
				for (int k=0; k<NO_OF_DIM; k++)
					tmpLength += Double.parseDouble(new BigDecimal(   Math.pow(orgData[x-1][k]-orgData[y-1][k], 2)   ).setScale(4, BigDecimal.ROUND_HALF_UP).toString());
				
				
				tmpLength = Double.parseDouble(new BigDecimal(   Math.sqrt(tmpLength)   ).setScale(4, BigDecimal.ROUND_HALF_UP).toString()); 
				
				avgEdgeLength += tmpLength;
				cCnt++;
			}
			
			avgEdgeLength = Double.parseDouble(new BigDecimal(   avgEdgeLength/(double)cCnt  ).setScale(4, BigDecimal.ROUND_HALF_UP).toString());
			
			// End of Step. 0 

			// Step. 1 Find nearest inner point of each component
			ArrayList<Double> arrLength = new ArrayList<Double>();     // Distances of inner points 
			ArrayList<Integer> arrIdx    = new ArrayList<Integer>();   // Indexes of inner points

			// Calculate average length between every points and edges of each component				
			for (int j=0; j<orgData.length; j++)
			{
				if (orgData[j][NO_OF_DIM] != 0.0)	//if point is already included in vertex, skip the point.
					continue;

				double tmpAverage =0;  
				for (int x=0; x<NO_OF_DIM; x++)
				{
					double tmpLength =0;  
					for (int k=0; k<NO_OF_DIM; k++){
						tmpLength += Double.parseDouble(new BigDecimal(   Math.pow(orgData[j][k] - orgData[getRecord[x]-1][k],2)   ).setScale(4, BigDecimal.ROUND_HALF_UP).toString());
					}
					tmpLength = Double.parseDouble(new BigDecimal(   Math.sqrt(tmpLength)   ).setScale(4, BigDecimal.ROUND_HALF_UP).toString());
					
					tmpAverage += tmpLength;
				}
				tmpAverage = Double.parseDouble(new BigDecimal(   tmpAverage/(double)NO_OF_DIM   ).setScale(4, BigDecimal.ROUND_HALF_UP).toString());
				
				arrLength.add(tmpAverage);
				arrIdx.add(j);
			}
			
			if(arrLength.isEmpty()){
				break;
			}
			
			// Find nearest inner point
			double shortestLength = 999999;
			int nearestPoint = 0;
			for (int k=0; k<arrLength.size(); k++)
			{
				double currLength = (double)arrLength.get(k);
				if (currLength < shortestLength)
				{
					// check if current point is close to neighbor compoinnt OH 20110111 
					{   ////////////////////////////////////////////////////////////////////////////

						int idxNearEdgePoint = -1;
						double minDistance = 999999;

						for (int m=0; m<NO_OF_DIM; m++)
						{
							double tmpDistance = calcEDistance(orgData[(int)arrIdx.get(k)], orgData[getRecord[m]-1]);
							if ( tmpDistance< minDistance)
							{
								minDistance = tmpDistance;
								idxNearEdgePoint = getRecord[m];
							}
						}
							
						// point is nearest to given component

						// collect components that link to given component
						ArrayList<String> linkComponent = new ArrayList<String>();

						for (int n=0; n<cvxList.size(); n++)
						{
							if (cvxList.get(n) == null || n == i)
								continue;

							int [] cvxRecord = cvxList.get(n); 

							for (int m=0; m<NO_OF_DIM; m++)
								if (cvxRecord[m]==(idxNearEdgePoint))
								{	
									linkComponent.add(String.valueOf(n));
									break;
								}
						}

						int closerToNeighbor =0;
						for (int r=0; r<linkComponent.size(); r++)
						{
							int idxLinkComponent = Integer.parseInt(linkComponent.get(r));
							if (calcPCDistance(orgData[(int)arrIdx.get(k)], idxLinkComponent) < calcPCDistance(orgData[(int)arrIdx.get(k)], i))
								closerToNeighbor =1;           
						}
						
						if (closerToNeighbor ==0)  
						{
							nearestPoint = (int)arrIdx.get(k);
							shortestLength = currLength;
						}	
					} ////////////////////////////////////////////////////////////////////////////
				}

			}


			//check if point is inside of edge(component). OH 20100701  
//			{   ////////////////////////////////////////////////////////////////////////////

				int idxNearEdgePoint = -1;
				double minDistance = 999999;

/*
				for (int m=0; m<NO_OF_DIM; m++)
				{
					double tmpDistance = calcEDistance(orgData[nearestPoint], orgData[getRecord[m]-1]);
					if ( tmpDistance< minDistance)
					{
						minDistance = tmpDistance;
						idxNearEdgePoint = getRecord[m];
					}
				}
					
				// point is nearest to given component

				// collect components that link to given component
				ArrayList<String> linkComponent = new ArrayList<String>();

				for (int n=0; n<cvxList.size(); n++)
				{
					if (cvxList.get(n) == null || n == i)
						continue;

					int [] cvxRecord = cvxList.get(n); 

					for (int m=0; m<NO_OF_DIM; m++)
						if (cvxRecord[m]==(idxNearEdgePoint))
						{	
							linkComponent.add(String.valueOf(n));
							break;
						}
				}

				int dig =1;
				for (int k=0; k<linkComponent.size(); k++)
				{
					int idxLinkComponent = Integer.parseInt(linkComponent.get(k));
					if (calcPCDistance(orgData[nearestPoint], idxLinkComponent) < calcPCDistance(orgData[nearestPoint], i))
						dig =0;
				}
				
				if (dig ==0)
					continue;             // goto i loop
*/
				// step. 2 Calculate shortest length between each point of component and nearest inner point.
				// This distance is called decision distance.
				double minLength = 99999;
				for (int x=0; x<NO_OF_DIM; x++)
				{
					double tmpLength =0;
					for (int k=0; k<NO_OF_DIM; k++){
						tmpLength += Math.pow(orgData[nearestPoint][k] - orgData[getRecord[x]-1][k],2);
					}
					tmpLength = Math.sqrt(tmpLength);
					if (tmpLength < minLength){
						minLength = tmpLength;
					}
				}	


			// step. 3 Compare the ratio of decision distance with threshold N.
			// if the ratio bigger than N, nearest inner point is inserted to concave list. 
		
			if (minLength > 0 && (double)avgEdgeLength/(double)minLength > N)
			{
				// 3.1 vertex flag on.
				orgData[nearestPoint][NO_OF_DIM] = 1;
				Integer compoNum =new Integer( cvxList.get(i)[NO_OF_DIM] );
				boldComponent = (int [])cvxList.get(i);
				cvxList.set(i, null) ;                                      // nullify

				// 3.2 make new components through combination of a selected component and nearest inner point.
				int tmpIdx =0;

				cg = new CombinationGenerator (NO_OF_DIM, NO_OF_DIM-1);
				while (cg.hasMore())
				{
					combination = new StringBuffer ();
					indices = cg.getNext ();
					int newRecord [] = new int[NO_OF_DIM+1];

					for (int q=0; q<NO_OF_DIM-1; q++)
						 newRecord[q] = getRecord[indices[q]]; 

					newRecord [NO_OF_DIM-1] = nearestPoint+1;
					newRecord [NO_OF_DIM] = compoNum;
					System.out.println("newRecord = " + newRecord[0] + "," + newRecord[1] );
					cvxList.add(newRecord);	//add new components
				
				
				// Calculate normal vector for newRecord  OH -------------
				double [] oldNormal = nvList.get(i);
				double [] newNormal = calcOneNormalVector(cvxList.size()-1, 1);

				double [] oppositePoint = findOppositePoint(i, cvxList.size()-1) ;
				double [] diggingPoint = orgData[nearestPoint] ;
				double [] vectorA = new double[NO_OF_DIM];
				for (int p=0; p<NO_OF_DIM; p++)
					vectorA[p] = oppositePoint[p] - diggingPoint[p];

				double result = calcAngle(vectorA, newNormal);
				if (Math.abs(result) >= 0 && Math.abs(result) <= 0.001)
				{
					for (int r=0; r<NO_OF_DIM; r++)
						newNormal[r] = oldNormal[r];
				} else if (result < 0)       
				{
					for (int q=0; q<NO_OF_DIM; q++)
						newNormal[q] *= -1;
				}
				nvList.add(newNormal);
				}

				//verify duplication in changedComponent.
				if(changedComponent.isEmpty()){
					changedComponent.add(compoNum);
				}
				else{
					if(!changedComponent.contains(compoNum)){
						changedComponent.add(compoNum);
					}
				}
			}
		}

		// Delete Nullified component
		for (int k=cvxList.size()-1; k>=0; k--)
		{
			if (cvxList.get(k) == null)
			{
				cvxList.remove(k);
				System.out.println("removed :" + k);
			} 
		}
		System.out.println("Work is finished --------------- "+cvxList.size());
	}
	
	/*////////////////////////////////////////////////////////////////////////////////////////////
	Concaveness
	compare the difference of each components of convex hull between concave hull.
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public void concaveness()
	{
		
		for(int i=0; i<cvxList.size();i++){
			concaveness_graph.add(0.0);
		}
		int concave_graph_index = 0;
		int last_concave_graph_index = 0;
		ArrayList<double []> points = new ArrayList<double []>();
		
		for(int i=0; i< changedComponent.size();i++){
			
			// get points of a component of convex hull that include many components of concave hull. 
			for(int j=0;j<NO_OF_DIM;j++){
				double temp[]=new double[NO_OF_DIM];
				for(int k=0;k<NO_OF_DIM; k++){
					temp[k] = orgData[(cvxList.get(changedComponent.get(i)))[j]-1][k];
				}
				points.add(temp);
			}
			
			// select each line of a component.
			CombinationGenerator cg = new CombinationGenerator (NO_OF_DIM, 2);
			double avgEdgeLength =0;
			int cCnt = 0;
			int[] indices;
			while (cg.hasMore())
			{
				ArrayList<Double> dif = new ArrayList<Double>();
				concave_graph_index = last_concave_graph_index;
				
				indices = cg.getNext ();
				for (int k=0; k<NO_OF_DIM; k++){
					dif.add(points.get(indices[0])[k]-points.get(indices[1])[k]);
				}
				
				// gather every points of components of concave hull in a component of convex hull  .
				ArrayList<Integer> pointsInChangedCompo = new ArrayList<Integer>();
				for(int j=0; j<cvxList.size(); j++){
					if(cvxList.get(j)[NO_OF_DIM] == changedComponent.get(i)){
						for(int m=0; m<NO_OF_DIM;m++){
							if(!pointsInChangedCompo.contains(cvxList.get(j)[m])){
								boolean add_flag = true;
								for(int p=0;p<NO_OF_DIM;p++){
									if(OriginalCvxList.get(changedComponent.get(i)-1)[p] == cvxList.get(j)[m]){
										add_flag = false;
									}
								}
								if(add_flag){
									pointsInChangedCompo.add(cvxList.get(j)[m]);
								}
							}
						}	
					}
				}
				
				//Calculate depth of each point of components of concave hull from selected line of a component of convex hull.
				for(int pg =0; pg<pointsInChangedCompo.size();pg++){
					double first_point [] = new double[NO_OF_DIM];
					for(int k=0; k<NO_OF_DIM; k++){
						first_point[k] = points.get(indices[1])[k];
					}
					
					double point_graph_value =0;

					double tmpLength []=new double[10];
					for(int j=0;j<10;j++){
						for (int k=0; k<NO_OF_DIM; k++){
							tmpLength[j] += Math.pow(first_point[k]-orgData[pointsInChangedCompo.get(pg)][k], 2);
						}
						tmpLength[j] = Math.sqrt(tmpLength[j]);
						for(int k=0; k<NO_OF_DIM; k++){
							first_point[k] = first_point[k] + (dif.get(k)/10);
						}
					}

					for(int j=0;j<10;j++){
						if(point_graph_value == 0){
							point_graph_value = tmpLength[j];
						}
						else{
							if(point_graph_value > tmpLength[j]){
								point_graph_value = tmpLength[j];
							}
						}
					}	
					concaveness_graph.set(changedComponent.get(i)+concave_graph_index-1, point_graph_value) ;
					concave_graph_index++;
				}
			}
			last_concave_graph_index = concave_graph_index;
		}
		System.out.println("Concaveness Done");
	}
	
	/*////////////////////////////////////////////////////////////////////////////////////////////
	Save concave hull list data and flagged original data 
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public void SaveRseult()
	{
		// Save CM value 
		try {
			FileWriter   fw_1 = new FileWriter("CMvalue");
			BufferedWriter bw_1 = new BufferedWriter(fw_1);
			PrintWriter outFile_1 = new PrintWriter(bw_1); 
			
			this.calcCM();
			outFile_1.print(value_cm);   
			outFile_1.close(); 

		} catch (IOException IOe) {
			System.err.println(IOe);
			System.exit(1);
		}
		// Save concaveness graph data
		try {
			FileWriter   fw_1 = new FileWriter("CMgraph");
			BufferedWriter bw_1 = new BufferedWriter(fw_1);
			PrintWriter outFile_1 = new PrintWriter(bw_1); 

			for (int i=0; i<concaveness_graph.size(); i++)
			{
				if (i == (concaveness_graph.size()-1)){
					outFile_1.print(concaveness_graph.get(i));
				}
				else{
					outFile_1.print(concaveness_graph.get(i)+", ");   
				}
			}

			outFile_1.close(); 

		} catch (IOException IOe) {
			System.err.println(IOe);
			System.exit(1);
		}

	}
	
	
	/*////////////////////////////////////////////////////////////////////////////////////////////
	Main
	////////////////////////////////////////////////////////////////////////////////////////////*/
	public static void main(String[] args) 
	{
		dkuCH_Concaveness obj = new dkuCH_Concaveness();
		
		// parsing and setting options
		if(args[0].equals("-p")){
			dataSetFile = args[1];
			cvxListFile = "result";
			ccvDataSetFile = args[2];
			ccvListFile = ccvDataSetFile +"_ccvList";
			NO_OF_DIM = obj.load_CountFeature();
			if (args.length == 4){
				N = Double.parseDouble(args[3]);
			}
			else{
				N = 2;
			}
		}
		else if(args[0].equals("-f")){
			cvxListFile = args[1];
			dataSetFile = args[2];
			ccvDataSetFile = args[3];
			ccvListFile = ccvDataSetFile +"_ccvList";
			NO_OF_DIM = obj.load_CountFeature();
			if (args.length == 5){
				N = Double.parseDouble(args[4]);
			}
			else{
				N = 2;
			}
		}	
		
		obj.convertFormat_Origin();
		obj.makeConvexList(); // call qconvex program.
		obj.convertFormat_Result();
		
		obj.loadConvexList();
		obj.loadOriginalData();
		
		obj.flagVertexPoints(); // flag convex list
		
		obj.calcClassCenter();
		obj.makeCvxNormalVector();
		
		obj.findConcave(); 
		obj.concaveness();
		obj.SaveRseult();	
	}
}
